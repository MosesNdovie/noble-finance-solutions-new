<?php
// Noble Finance Solutions theme. The page is fully self-contained in index.php.
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_theme_support( 'title-tag' );
