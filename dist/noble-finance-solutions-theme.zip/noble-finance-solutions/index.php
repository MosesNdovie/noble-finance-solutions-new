<?php
/**
 * Noble Finance Solutions single-page site.
 * Built by Moses Ndovie. Served for every URL on the site.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0e2246">
<meta name="description" content="Noble Finance Solutions helps families in Tulsa County and surrounding areas plan for life insurance, retirement income, long-term care, debt protection and final expenses. Take the free Financial Protection Health Check.">
<link rel="icon" type="image/png" sizes="96x96" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/favicon.png?v=3">
<link rel="apple-touch-icon" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/apple-touch-icon.png?v=3">
<title>Noble Finance Solutions | Protect What Matters</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;0,700;1,500;1,600&display=swap" rel="stylesheet">

<style>
:root {
  --navy:#0e2246;
  --navy-light:#183262;
  --purple:#1f5bb5;
  --purple-light:#5b8ad6;
  --gold:#d8ad65;
  --ivory:#f8f7f4;
  --white:#ffffff;
  --text:#17233c;
  --muted:#68758b;
  --border:#e7e8ed;
}

* {box-sizing:border-box}

html {scroll-behavior:smooth}

body {
  margin:0;
  font-family:"DM Sans",sans-serif;
  color:var(--text);
  background:var(--white);
}

a {text-decoration:none;color:inherit}
button {font:inherit;cursor:pointer}

.container {
  width:min(1180px,90%);
  margin:auto;
}

h1,h2,h3 {
  font-family:Outfit,sans-serif;
  letter-spacing:-.035em;
}

h1 {
  font-size:clamp(3rem,6vw,5.7rem);
  line-height:1.07;
  font-weight:700;
  margin:23px 0;
}

h2 {
  font-size:clamp(2rem,4vw,3.5rem);
  line-height:1.14;
  margin:15px 0;
}

p {line-height:1.8}

.eyebrow {
  color:var(--purple);
  font-size:12px;
  font-weight:800;
  letter-spacing:2.5px;
  text-transform:uppercase;
}

.section {padding:105px 0}
.center {text-align:center}

.section-intro {
  max-width:630px;
  margin:15px auto;
  color:var(--muted);
}

.btn {
  display:inline-flex;
  align-items:center;
  justify-content:center;
  gap:12px;
  padding:16px 26px;
  border-radius:9px;
  font-size:14px;
  font-weight:700;
  border:1px solid transparent;
  transition:.3s;
}

.btn:hover {
  transform:translateY(-3px);
  box-shadow:0 12px 30px #0002;
}

.btn-purple {
  background:var(--purple);
  color:white;
}

.btn-gold {
  background:var(--gold);
  color:var(--navy);
}

.btn-white {
  background:white;
  color:var(--navy);
}

.btn-outline {
  border-color:#ffffff60;
  color:white;
}

.btn-dark {
  background:var(--navy);
  color:white;
}

/* NAVIGATION */

header {
  position:sticky;
  top:0;
  z-index:1000;
  background:rgba(17,27,58,.97);
  backdrop-filter:blur(20px);
  border-bottom:1px solid #ffffff18;
}

.nav {
  height:86px;
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:25px;
}

.logo {
  display:flex;
  align-items:center;
  gap:12px;
  color:white;
  font-family:Outfit,sans-serif;
  font-size:23px;
  font-weight:800;
}

.logo-icon {
  background:linear-gradient(135deg,var(--gold),#f4d49a);
  color:var(--navy);
  width:43px;
  height:43px;
  display:grid;
  place-items:center;
  border-radius:12px;
  font-size:26px;
  font-weight:800;
}

.logo small {
  display:block;
  font-size:9px;
  letter-spacing:2.7px;
  color:#bac5d9;
  margin-top:2px;
}

.nav-links {
  display:flex;
  gap:32px;
  align-items:center;
}

.nav-links a {
  font-size:14px;
  color:#d7ddec;
  transition:.3s;
}

.nav-links a:hover {color:var(--gold)}

.menu {
  display:none;
  background:none;
  border:0;
  color:white;
  font-size:28px;
}

/* HERO SECTION */

.hero {
  color:white;
  background:
    radial-gradient(circle at 85% 25%,#24467f 0%,transparent 38%),
    radial-gradient(circle at 5% 95%,#1a2d5c 0%,transparent 42%),
    var(--navy);
  overflow:hidden;
  position:relative;
}

.hero:before {
  content:"";
  position:absolute;
  inset:0;
  background-image:radial-gradient(#ffffff18 1px,transparent 1px);
  background-size:26px 26px;
  mask-image:linear-gradient(to right,transparent,#000);
  pointer-events:none;
}

.hero-grid {
  display:grid;
  grid-template-columns:1.1fr .9fr;
  gap:70px;
  align-items:center;
  padding:110px 0 130px;
  position:relative;
}

.hero .eyebrow {color:var(--gold)}

.hero h1 span {
  background:linear-gradient(120deg,#f7d79e,var(--gold));
  background-clip:text;
  -webkit-background-clip:text;
  color:transparent;
}

.hero p {
  color:#bdc7df;
  font-size:17px;
  max-width:540px;
}

.hero-buttons {
  display:flex;
  gap:15px;
  flex-wrap:wrap;
  margin-top:35px;
}

.hero-trust {
  margin-top:49px;
  display:flex;
  align-items:center;
  gap:12px;
  color:#d5dcef;
  font-size:13px;
}

.trust-icon {
  width:37px;
  height:37px;
  border-radius:50%;
  display:grid;
  place-items:center;
  background:#d8ad6525;
  color:var(--gold);
}

/* FINANCIAL ILLUSTRATION */

.visual {
  position:relative;
  padding:15px;
  animation:float 7s ease-in-out infinite;
}

.glass-card {
  background:linear-gradient(145deg,#ffffff20,#ffffff09);
  border:1px solid #ffffff35;
  border-radius:25px;
  padding:30px;
  backdrop-filter:blur(20px);
  box-shadow:0 35px 80px #080e2b77;
}

.glass-head {
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:12px;
}

.glass-head small {
  color:#c7c8e4;
  letter-spacing:1.4px;
}

.glass-head h3 {
  font-size:23px;
  margin:10px 0;
}

.pill {
  background:#ffffff20;
  border:1px solid #ffffff25;
  border-radius:30px;
  padding:9px 13px;
  font-size:11px;
  white-space:nowrap;
}

.chart {
  width:100%;
  height:auto;
  margin:30px 0 15px;
}

.chart-path {
  stroke-dasharray:900;
  stroke-dashoffset:900;
  animation:draw 3s ease forwards;
}

.chart-stats {
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:10px;
}

.chart-stat {
  background:#ffffff0c;
  border:1px solid #ffffff20;
  border-radius:12px;
  padding:17px 8px;
  text-align:center;
}

.chart-stat strong {
  display:block;
  font-family:Outfit,sans-serif;
  font-size:25px;
  color:var(--gold);
}

.chart-stat small {
  color:#c4cee1;
  font-size:10px;
}

.floating-tag {
  position:absolute;
  top:-14px;
  right:-10px;
  background:white;
  color:var(--navy);
  padding:18px 22px;
  border-radius:13px;
  box-shadow:0 20px 35px #0004;
  font-size:13px;
  font-weight:700;
}

.floating-tag span {color:var(--purple)}

/* HIGHLIGHT STRIP */

.highlights {
  background:#fff;
  border-bottom:1px solid var(--border);
}

.highlight-grid {
  display:grid;
  grid-template-columns:repeat(3,1fr);
}

.highlight {
  display:flex;
  align-items:center;
  justify-content:center;
  gap:17px;
  padding:30px;
  border-right:1px solid var(--border);
}

.highlight:last-child {border:0}

.highlight-icon {
  font-size:25px;
  color:var(--purple);
}

.highlight strong {
  display:block;
  font-size:15px;
}

.highlight small {
  display:block;
  color:var(--muted);
  margin-top:5px;
}

/* SERVICE CARDS */

.services {background:var(--ivory)}

.service-grid {
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:25px;
  margin-top:55px;
}

.service-card {
  background:white;
  padding:38px;
  border-radius:19px;
  border:1px solid var(--border);
  transition:.35s;
  position:relative;
  overflow:hidden;
}

.service-card:before {
  content:"";
  position:absolute;
  top:0;
  left:0;
  width:100%;
  height:4px;
  background:linear-gradient(90deg,var(--purple),var(--gold));
  transform:scaleX(0);
  transform-origin:left;
  transition:.35s;
}

.service-card:hover {
  transform:translateY(-10px);
  box-shadow:0 25px 60px #19234214;
}

.service-card:hover:before {transform:scaleX(1)}

.service-icon {
  width:69px;
  height:69px;
  border-radius:17px;
  display:grid;
  place-items:center;
  background:#eaf1fb;
  color:var(--purple);
  font-size:30px;
}

.service-card:nth-child(2) .service-icon {
  background:#fff3df;
  color:#b28234;
}

.service-card:nth-child(3) .service-icon {
  background:#e9f5ff;
  color:#4078b5;
}

.service-card h3 {
  font-size:24px;
  margin:30px 0 12px;
}

.service-card p {
  color:var(--muted);
  font-size:15px;
}

.service-card a {
  display:inline-block;
  color:var(--purple);
  font-weight:700;
  margin-top:22px;
}

/* ABOUT */

.about-grid {
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:85px;
  align-items:center;
}

.about-visual {
  min-height:470px;
  border-radius:22px;
  background:linear-gradient(135deg,#16305e,#2b5596);
  display:grid;
  place-items:center;
  position:relative;
  overflow:hidden;
}

.orbit {
  position:absolute;
  width:350px;
  height:350px;
  border:1px solid #ffffff50;
  border-radius:50%;
}

.orbit.two {width:255px;height:255px}
.orbit.three {width:430px;height:430px;opacity:.3}

.about-logo {
  position:relative;
  width:160px;
  height:160px;
  background:linear-gradient(135deg,#f7dcae,#c99b50);
  border-radius:32px;
  display:grid;
  place-items:center;
  font:800 105px Outfit,sans-serif;
  color:var(--navy);
  box-shadow:0 25px 60px #0004;
  transform:rotate(-8deg);
}

.about-text p {color:var(--muted)}

.feature {
  display:flex;
  gap:13px;
  align-items:center;
  padding:12px 0;
  font-weight:600;
}

.feature span {
  display:grid;
  place-items:center;
  width:27px;
  height:27px;
  border-radius:50%;
  background:#eaf1fb;
  color:var(--purple);
}

/* STEPS */

.process {
  background:var(--navy);
  color:white;
}

.process .eyebrow {color:var(--gold)}
.process .section-intro {color:#c2cbdd}

.steps {
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:35px;
  margin-top:60px;
}

.step {
  padding:32px 25px;
  border:1px solid #ffffff24;
  border-radius:16px;
  background:#ffffff08;
}

.step-no {
  font:800 48px Outfit,sans-serif;
  color:var(--gold);
}

.step h3 {
  font-size:24px;
  margin:20px 0 10px;
}

.step p {
  color:#b8c4d9;
  font-size:15px;
}

/* TESTIMONIAL-STYLE MESSAGE */

.message {background:#eef3fa}

.message-panel {
  text-align:center;
  max-width:850px;
  margin:auto;
}

.quote-mark {
  font-size:75px;
  font-family:Georgia,serif;
  color:var(--purple);
  line-height:1;
}

.message h2 {
  font-size:clamp(1.8rem,3.5vw,3rem);
  font-weight:500;
}

.message p {color:var(--muted)}

/* FAQ */

.faq-grid {
  display:grid;
  grid-template-columns:.8fr 1.2fr;
  gap:75px;
}

details {
  padding:23px 0;
  border-bottom:1px solid var(--border);
}

summary {
  cursor:pointer;
  font-weight:700;
  font-size:16px;
}

details p {
  color:var(--muted);
  margin-bottom:0;
}

/* CONTACT */

.contact {
  padding:95px 0;
  background:var(--ivory);
}

.contact-panel {
  background:linear-gradient(120deg,var(--navy),#1d3f73);
  color:white;
  padding:85px 40px;
  text-align:center;
  border-radius:25px;
  position:relative;
  overflow:hidden;
}

.contact-panel:before {
  content:"";
  position:absolute;
  width:350px;
  height:350px;
  border:1px solid #ffffff30;
  border-radius:50%;
  right:-140px;
  top:-150px;
}

.contact-panel h2 {
  max-width:700px;
  margin:20px auto;
}

.contact-panel p {
  color:#c8d0e8;
  margin-bottom:35px;
}

/* FOOTER */

footer {
  background:#0b1430;
  color:#aebad0;
  padding:70px 0 25px;
}

.footer-grid {
  display:grid;
  grid-template-columns:1.5fr 1fr 1fr;
  gap:60px;
  padding-bottom:55px;
}

footer p {font-size:14px}

footer h4 {
  color:white;
  font:700 16px Outfit,sans-serif;
  margin-top:0;
}

.footer-links {
  display:flex;
  flex-direction:column;
  gap:13px;
  font-size:14px;
}

.footer-links a:hover {color:var(--gold)}

.copyright {
  border-top:1px solid #ffffff20;
  padding-top:23px;
  font-size:12px;
  line-height:1.8;
}

/* ANIMATIONS */

.reveal {
  opacity:0;
  transform:translateY(30px);
  transition:opacity .75s,transform .75s;
}

.reveal.active {
  opacity:1;
  transform:translateY(0);
}

@keyframes float {
  0%,100% {transform:translateY(0)}
  50% {transform:translateY(-13px)}
}

@keyframes draw {
  to {stroke-dashoffset:0}
}

/* MOBILE */

@media(max-width:950px) {
  .hero-grid,.about-grid,.faq-grid {
    grid-template-columns:1fr;
    gap:55px;
  }

  .service-grid,.steps,.footer-grid {
    grid-template-columns:1fr;
  }

  .hero-grid {padding:85px 0}

  .nav-links {
    display:none;
    position:absolute;
    top:86px;
    left:0;
    right:0;
    padding:28px 6%;
    flex-direction:column;
    align-items:stretch;
    background:var(--navy);
  }

  .nav-links.open {display:flex}
  .menu {display:block}
  .section {padding:75px 0}

  .highlight-grid {grid-template-columns:1fr}
  .highlight {
    justify-content:flex-start;
    border-right:0;
    border-bottom:1px solid var(--border);
  }
}

@media(max-width:550px) {
  .glass-card {padding:20px}
  .floating-tag {right:0;top:-25px}
  .chart-stat strong {font-size:20px}
  .contact-panel {padding:60px 22px}
  .hero-buttons {flex-direction:column;align-items:stretch}
  .about-visual {min-height:350px}
}

@media(prefers-reduced-motion:reduce) {
  *,*:before,*:after {
    animation:none!important;
    transition:none!important;
    scroll-behavior:auto!important;
  }
  .reveal {opacity:1;transform:none}
}

/* ===== ANNOUNCEMENT BAR ===== */
.announce {
  background:linear-gradient(90deg,#d8ad65,#f1d29a,#d8ad65);
  color:var(--navy);
  font-size:13px;
  font-weight:600;
}
.announce .container {
  display:flex;
  justify-content:center;
  align-items:center;
  gap:10px 22px;
  flex-wrap:wrap;
  padding:10px 0;
  text-align:center;
}
.announce a {text-decoration:underline;text-underline-offset:3px;font-weight:800}
.announce .dot {width:7px;height:7px;border-radius:50%;background:var(--navy);display:inline-block;margin-right:8px;vertical-align:1px;animation:pulse 2s infinite}
@keyframes pulse {0%,100%{opacity:1}50%{opacity:.25}}

.motto {
  display:flex;
  flex-wrap:wrap;
  gap:8px;
  margin-top:6px;
}
.motto span {
  font-size:11px;
  font-weight:800;
  letter-spacing:2px;
  color:var(--gold);
  border:1px solid #d8ad6555;
  border-radius:30px;
  padding:7px 13px;
}

/* ===== SERVICE GRID (5 cards) ===== */
.service-grid.five {grid-template-columns:repeat(6,1fr)}
.service-grid.five .service-card {grid-column:span 2}
.service-grid.five .service-card:nth-child(n+4) {grid-column:span 3}
.service-card:nth-child(4) .service-icon {background:#e8f6ef;color:#2f8a63}
.service-card:nth-child(5) .service-icon {background:#fbeef3;color:#b4537b}
.service-card .stat-chip {
  display:inline-block;
  margin-top:4px;
  font-size:12px;
  font-weight:700;
  color:#8a6526;
  background:#fbf2e2;
  padding:6px 11px;
  border-radius:20px;
}

/* ===== 5 RISKS EXPLORER ===== */
.risks {
  background:
    radial-gradient(circle at 10% 0%,#fbf2e2 0%,transparent 40%),
    radial-gradient(circle at 100% 100%,#eaf1fb 0%,transparent 45%),
    #fff;
}
.risks-head {
  display:grid;
  grid-template-columns:auto 1fr;
  gap:28px;
  align-items:center;
  max-width:900px;
  margin:0 auto 55px;
}
.big-five {
  font:800 clamp(7rem,14vw,11rem)/.8 Outfit,sans-serif;
  color:var(--navy);
  letter-spacing:-.06em;
}
.risks-head h2 {margin:8px 0 10px}
.risks-head h2 em {font-style:normal;color:var(--gold)}
.risks-head p {color:var(--muted);margin:0}

.risk-explorer {
  display:grid;
  grid-template-columns:330px 1fr;
  gap:26px;
  align-items:stretch;
}
.risk-tabs {
  display:flex;
  flex-direction:column;
  gap:10px;
}
.risk-tab {
  display:grid;
  grid-template-columns:46px 1fr;
  gap:14px;
  align-items:center;
  width:100%;
  text-align:left;
  padding:15px 16px;
  border-radius:15px;
  border:1px solid var(--border);
  background:white;
  color:var(--text);
  position:relative;
  overflow:hidden;
  transition:.3s;
}
.risk-tab:hover {border-color:#d8ad65;transform:translateX(4px)}
.risk-tab .num {
  width:46px;height:46px;border-radius:50%;
  display:grid;place-items:center;
  font:800 20px Outfit,sans-serif;
  background:#fbf2e2;color:#a87a2f;
  transition:.3s;
}
.risk-tab strong {display:block;font:700 16px Outfit,sans-serif;letter-spacing:-.01em}
.risk-tab small {display:block;color:var(--muted);font-size:12.5px;margin-top:3px}
.risk-tab .timer {
  position:absolute;left:0;bottom:0;height:3px;width:0;
  background:linear-gradient(90deg,var(--purple),var(--gold));
}
.risk-tab[aria-selected="true"] {
  background:var(--navy);
  border-color:var(--navy);
  color:white;
  box-shadow:0 18px 40px #0e224630;
}
.risk-tab[aria-selected="true"] small {color:#bcc6dc}
.risk-tab[aria-selected="true"] .num {background:var(--gold);color:var(--navy)}
.risk-explorer.autoplay .risk-tab[aria-selected="true"] .timer {animation:timer 8s linear forwards}
@keyframes timer {to{width:100%}}

.risk-panel {
  background:white;
  border:1px solid var(--border);
  border-radius:24px;
  overflow:hidden;
  display:grid;
  grid-template-rows:auto 1fr;
  box-shadow:0 30px 70px #19234212;
}
.risk-photo {
  position:relative;
  background:#eee center 30%/cover no-repeat;
  height:270px;
  transition:background-image .2s;
}
.risk-photo:after {
  content:"";position:absolute;inset:0;
  background:linear-gradient(180deg,transparent 40%,#0e2246d9);
}
.risk-photo .badge-num {
  position:absolute;top:20px;left:20px;z-index:1;
  width:62px;height:62px;border-radius:50%;
  display:grid;place-items:center;
  background:var(--gold);color:var(--navy);
  font:800 30px Outfit,sans-serif;
  border:4px solid white;
  box-shadow:0 10px 25px #0003;
}
.stat-ring {
  position:absolute;left:22px;right:22px;bottom:22px;z-index:1;
  display:flex;align-items:center;gap:16px;color:white;
}
.stat-ring svg {width:92px;height:92px;flex-shrink:0;transform:rotate(-90deg)}
.stat-ring .ring-bg {stroke:#ffffff35}
.stat-ring .ring-fg {stroke:var(--gold);stroke-linecap:round;transition:stroke-dashoffset 1.3s cubic-bezier(.2,.8,.2,1)}
.stat-ring .stat-value {font:800 clamp(2rem,3.4vw,2.8rem)/1 Outfit,sans-serif;letter-spacing:-.03em;color:#f6d69c}
.stat-ring .stat-label {font-size:13px;color:#dce3f1;line-height:1.45;margin-top:6px}
.risk-body {padding:30px 36px 30px;display:grid;grid-template-columns:1fr 1fr;gap:0 34px;align-content:start}
.risk-body > .eyebrow, .risk-body > h3, .risk-body > .key-fact, .risk-body > p {grid-column:1}
.risk-body > .ask {grid-column:2;grid-row:1 / span 4;margin-top:0;border-top:0;border-left:1px dashed var(--border);padding:4px 0 0 30px}
.risk-body > .risk-actions {grid-column:1 / -1;margin-top:6px}
.risk-body .eyebrow {margin-bottom:6px}
.risk-body h3 {font-size:clamp(1.7rem,2.6vw,2.2rem);margin:0 0 14px}
.key-fact {
  background:#fbf2e2;
  border-left:4px solid var(--gold);
  border-radius:0 12px 12px 0;
  padding:13px 16px;
  font-size:15px;
  margin-bottom:16px;
}
.key-fact b {color:#a87a2f}
.risk-body > p {color:var(--muted);font-size:15.5px;margin:0 0 18px}
.ask {
  margin-top:auto;
  border-top:1px dashed var(--border);
  padding-top:18px;
}
.ask-title {display:flex;align-items:center;gap:10px;font:700 14px Outfit,sans-serif;letter-spacing:.02em;margin-bottom:10px}
.ask-title span {
  width:30px;height:30px;border-radius:50%;display:grid;place-items:center;
  background:var(--gold);color:var(--navy);font-weight:800;
}
.ask ul {margin:0;padding:0;list-style:none;display:grid;gap:8px}
.ask li {
  display:flex;gap:10px;font-size:14.5px;line-height:1.5;
}
.ask li:before {content:"→";color:var(--purple);font-weight:800}
.risk-actions {display:flex;flex-wrap:wrap;gap:10px;margin-top:20px}
.risk-actions .btn {padding:13px 18px;font-size:13px}
.btn-ghost {border-color:var(--border);color:var(--navy);background:white}
.risk-panel.swap .risk-body > *, .risk-panel.swap .stat-ring {animation:swapIn .5s ease both}
@keyframes swapIn {from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}

/* ===== HEALTH CHECK ===== */
.checkup {
  background:
    radial-gradient(circle at 90% 10%,#24467f 0%,transparent 35%),
    radial-gradient(circle at 0% 100%,#1a2d5c 0%,transparent 40%),
    var(--navy);
  color:white;
  position:relative;
  overflow:hidden;
}
.checkup .eyebrow {color:var(--gold)}
.checkup-grid {
  display:grid;
  grid-template-columns:1.35fr .65fr;
  gap:30px;
  align-items:start;
}
.quiz-card {
  background:white;
  color:var(--text);
  border-radius:26px;
  padding:40px;
  box-shadow:0 40px 90px #05092066;
  min-height:470px;
  display:flex;
  flex-direction:column;
}
.quiz-meta {
  display:flex;justify-content:space-between;align-items:center;gap:12px;
  font-size:13px;color:var(--muted);font-weight:600;
}
.quiz-meta .cat {
  display:inline-flex;align-items:center;gap:7px;
  color:#a87a2f;background:#fbf2e2;border-radius:20px;padding:6px 12px;font-weight:700;
}
.progress {height:8px;background:#eef0f5;border-radius:10px;margin:16px 0 32px;overflow:hidden}
.progress span {display:block;height:100%;width:0;background:linear-gradient(90deg,var(--purple),var(--gold));border-radius:10px;transition:width .45s}
.quiz-q {font:700 clamp(1.45rem,2.6vw,2rem)/1.25 Outfit,sans-serif;letter-spacing:-.02em;margin:0 0 26px}
.answers {display:grid;grid-template-columns:1fr 1fr;gap:12px}
.answer {
  text-align:left;
  padding:17px 18px;
  border-radius:14px;
  border:1.5px solid var(--border);
  background:white;
  color:var(--text);
  font-weight:600;
  font-size:15px;
  display:flex;align-items:center;gap:12px;
  transition:.2s;
}
.answer i {
  font-style:normal;width:28px;height:28px;border-radius:8px;flex-shrink:0;
  display:grid;place-items:center;background:#f1f2f6;font-size:13px;font-weight:800;color:var(--muted);
}
.answer:hover {border-color:var(--purple);background:#f3f7fd;transform:translateY(-2px)}
.answer.chosen {border-color:var(--purple);background:#eaf1fb}
.answer.chosen i {background:var(--purple);color:white}
.quiz-nav {display:flex;justify-content:space-between;align-items:center;margin-top:auto;padding-top:26px;font-size:13px;color:var(--muted)}
.link-btn {background:none;border:0;color:var(--purple);font-weight:700;padding:6px 0}
.link-btn:disabled {color:#c3c7d2;cursor:default}

.quiz-start h3 {font-size:clamp(1.7rem,3vw,2.4rem);margin:4px 0 12px;line-height:1.15}
.quiz-start p {color:var(--muted);margin:0 0 20px}
.chips {display:flex;flex-wrap:wrap;gap:8px;margin-bottom:28px}
.chips span {font-size:13px;font-weight:700;color:var(--purple);background:#eaf1fb;border-radius:20px;padding:7px 13px}
.cover-list {display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:0 0 30px}
.cover-list div {
  text-align:center;padding:14px 6px;border-radius:12px;background:var(--ivory);
  font-size:12px;font-weight:700;color:var(--navy);line-height:1.3;
}
.cover-list div b {display:block;font:800 20px Outfit,sans-serif;color:var(--gold);margin-bottom:4px}

.result-top {display:grid;grid-template-columns:190px 1fr;gap:28px;align-items:center}
.gauge {position:relative;width:190px;height:190px}
.gauge svg {width:100%;height:100%;transform:rotate(-90deg)}
.gauge .g-bg {stroke:#eef0f5}
.gauge .g-fg {stroke:url(#gaugeGrad);stroke-linecap:round;transition:stroke-dashoffset 1.6s cubic-bezier(.2,.8,.2,1)}
.gauge-label {position:absolute;inset:0;display:grid;place-items:center;text-align:center}
.gauge-label strong {display:block;font:800 52px/1 Outfit,sans-serif;color:var(--navy)}
.gauge-label small {color:var(--muted);font-size:12px;font-weight:700;letter-spacing:1px}
.result-top h3 {font-size:clamp(1.5rem,2.6vw,2rem);margin:6px 0 8px}
.result-top p {color:var(--muted);margin:0;font-size:15px;line-height:1.7}
.tier {display:inline-block;font-size:12px;font-weight:800;letter-spacing:1.5px;padding:6px 12px;border-radius:20px}
.cat-bars {display:grid;gap:12px;margin:30px 0 8px}
.cat-bar {display:grid;grid-template-columns:150px 1fr 48px;gap:14px;align-items:center;font-size:14px;font-weight:600}
.cat-bar .track {height:10px;background:#eef0f5;border-radius:10px;overflow:hidden}
.cat-bar .fill {height:100%;width:0;border-radius:10px;transition:width 1.2s cubic-bezier(.2,.8,.2,1)}
.cat-bar em {font-style:normal;text-align:right;color:var(--muted);font-size:13px}
.cat-bar.priority {color:#b4537b}
.cat-bar.priority span:first-child:after {content:" · priority";font-size:11px;font-weight:800;letter-spacing:.5px}
.result-actions {display:flex;flex-wrap:wrap;gap:12px;margin-top:24px;align-items:center}

.checkup-side {display:grid;gap:18px}
.side-card {
  border:1px solid #ffffff28;
  background:linear-gradient(145deg,#ffffff16,#ffffff06);
  border-radius:22px;
  padding:28px;
  backdrop-filter:blur(14px);
}
.side-card h3 {font-size:20px;margin:0 0 8px}
.side-card p {color:#c2cbdd;font-size:14px;line-height:1.7;margin:0}
.qr-box {display:flex;gap:18px;align-items:center}
.qr-box img {width:112px;height:112px;background:white;border-radius:14px;padding:8px;flex-shrink:0}
.qr-box a {color:var(--gold);font-weight:700;font-size:14px;display:inline-block;margin-top:10px}
.privacy {display:flex;gap:12px;align-items:flex-start}
.privacy span {color:var(--gold);font-size:20px;line-height:1.3}
.checkup .disclaimer {color:#9eabc6;font-size:12.5px;line-height:1.7;margin:24px 0 0;max-width:820px}

/* ===== ADVISOR ===== */
.advisor-visual {background:linear-gradient(135deg,#16305e,#24467f)}
.advisor-photo {
  position:relative;
  width:min(320px,70%);
  aspect-ratio:1;
  border-radius:50%;
  border:6px solid #ffffff;
  box-shadow:0 30px 70px #0006;
  object-fit:cover;
  background:#c9ccd3;
}
.name-card {
  position:absolute;
  left:24px;bottom:24px;
  background:white;
  border-radius:16px;
  padding:16px 20px;
  box-shadow:0 20px 40px #0004;
}
.name-card strong {display:block;font:800 19px Outfit,sans-serif;color:var(--navy)}
.name-card small {color:var(--muted);font-size:12.5px}
.badge-row {position:absolute;right:24px;top:24px;display:flex;flex-direction:column;gap:8px;align-items:flex-end}
.badge-row span {
  background:#ffffffe8;color:var(--navy);font-size:11.5px;font-weight:800;letter-spacing:.3px;
  padding:8px 12px;border-radius:30px;display:flex;align-items:center;gap:6px;
}
.badge-row span b {color:#2f8a63}
.pillars {display:grid;gap:12px;margin:22px 0 26px}
.pillar {
  display:grid;grid-template-columns:42px 1fr;gap:14px;align-items:start;
  padding:16px 18px;border:1px solid var(--border);border-radius:14px;background:white;
  transition:.3s;
}
.pillar:hover {border-color:#bcd0ee;box-shadow:0 12px 30px #1f5bb514}
.pillar > span {
  width:42px;height:42px;border-radius:50%;display:grid;place-items:center;
  background:var(--navy);color:white;font:800 17px Outfit,sans-serif;
}
.pillar strong {display:block;font:700 16px Outfit,sans-serif}
.pillar small {display:block;color:var(--muted);font-size:14px;margin-top:3px;line-height:1.55}
.service-area {
  display:inline-flex;align-items:center;gap:8px;font-size:13px;font-weight:700;
  color:#2f8a63;background:#e8f6ef;border-radius:20px;padding:7px 13px;margin-bottom:6px;
}

/* ===== CONTACT ===== */
.contact-cards {
  display:grid;grid-template-columns:repeat(3,1fr);gap:14px;
  max-width:860px;margin:0 auto 34px;position:relative;
}
.contact-cards a {
  display:flex;align-items:center;gap:12px;justify-content:center;
  background:#ffffff12;border:1px solid #ffffff28;border-radius:14px;padding:16px;
  font-size:14px;font-weight:600;transition:.3s;word-break:break-word;
}
.contact-cards a:hover {background:#ffffff22;transform:translateY(-3px)}
.contact-cards a span {
  width:36px;height:36px;border-radius:50%;flex-shrink:0;display:grid;place-items:center;
  background:var(--gold);color:var(--navy);font-weight:800;font-size:15px;
}
.contact-tagline {
  display:flex;justify-content:center;gap:10px 30px;flex-wrap:wrap;
  margin-top:34px;font:700 13px Outfit,sans-serif;letter-spacing:2px;color:#d8ad65;
}
.signature {font:italic 600 clamp(1.4rem,2.6vw,2rem) Georgia,serif;color:var(--navy);margin-top:10px}

@media(max-width:1100px) {
  .risk-explorer {grid-template-columns:1fr}
  .risk-tabs {flex-direction:row;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:6px}
  .risk-tab {min-width:220px;scroll-snap-align:start}
  .risk-tab:hover {transform:none}
  .checkup-grid {grid-template-columns:1fr}
  .checkup-side {grid-template-columns:1fr 1fr}
}
@media(max-width:950px) {
  .service-grid.five {grid-template-columns:1fr}
  .service-grid.five .service-card, .service-grid.five .service-card:nth-child(n+4) {grid-column:auto}
  .risk-body {grid-template-columns:1fr}
  .risk-body > .ask {grid-column:1;grid-row:auto;border-left:0;border-top:1px dashed var(--border);padding:18px 0 0}
  .risk-photo {height:240px}
  .risks-head {grid-template-columns:1fr;text-align:center;gap:0}
  .contact-cards {grid-template-columns:1fr}
}
@media(max-width:640px) {
  .quiz-card {padding:26px 20px}
  .answers {grid-template-columns:1fr}
  .cover-list {grid-template-columns:repeat(3,1fr)}
  .result-top {grid-template-columns:1fr;justify-items:center;text-align:center}
  .cat-bar {grid-template-columns:110px 1fr 40px;gap:10px;font-size:13px}
  .checkup-side {grid-template-columns:1fr}
  .risk-body {padding:28px 22px}
  .badge-row {right:14px;top:14px}
  .name-card {left:14px;bottom:14px}
  .announce .hide-sm {display:none}
}

/* ================= POLISH PASS ================= */
:root {--serif:"Playfair Display",Georgia,serif;--shadow-lg:0 30px 70px #0e224618}
body {font-size:16px}
::selection {background:#d8ad6566}

/* Brand logo */
.logo {gap:0}
.brand-logo {height:54px;width:auto;display:block}
footer .brand-logo {height:62px}

/* Serif accents for elegance (matches flyer typography) */
.serif-accent, h2 span, h2 em, .risks-head h2 em {
  font-family:var(--serif)!important;
  font-style:italic;
  font-weight:600;
  letter-spacing:-.01em;
}
.hero h1 .serif-accent {
  background:linear-gradient(110deg,#f7dfae 0%,#d8ad65 45%,#f7dfae 70%,#c99545 100%);
  background-size:220% auto;
  -webkit-background-clip:text;background-clip:text;color:transparent;
  animation:shine 6s linear infinite;
  padding-right:.08em;
}
@keyframes shine {to{background-position:-220% center}}
.eyebrow {display:inline-flex;align-items:center;gap:10px}
.eyebrow:before {content:"";width:22px;height:2px;background:currentColor;opacity:.6;border-radius:2px}
.center .eyebrow:after {content:"";width:22px;height:2px;background:currentColor;opacity:.6;border-radius:2px}

/* Buttons: subtle sheen */
.btn {position:relative;overflow:hidden}
.btn:after {
  content:"";position:absolute;top:0;left:-60%;width:40%;height:100%;
  background:linear-gradient(100deg,transparent,#ffffff55,transparent);
  transform:skewX(-20deg);transition:left .6s;
}
.btn:hover:after {left:120%}
.btn-gold {background:linear-gradient(135deg,#f1d29a,#d8ad65 55%,#c99545);box-shadow:0 10px 25px #d8ad6540}
header {background:rgba(14,34,70,.92)}
header.scrolled {box-shadow:0 10px 30px #0e224633}

/* ===== HERO SCENE ===== */
.hero {background:radial-gradient(circle at 80% 30%,#24467f 0%,transparent 45%),radial-gradient(circle at 0% 100%,#1a2d5c 0%,transparent 45%),var(--navy)}
.hero-grid {padding:90px 0 120px;z-index:1}
.nav-links a.btn-gold {color:var(--navy)}
.nav-links a.btn-gold:hover {color:var(--navy)}
.scene-wrap {position:relative;padding:30px 40px 40px 30px}
.scene {
  position:relative;border-radius:200px 200px 28px 28px;overflow:hidden;
  aspect-ratio:5/6;max-height:560px;margin-left:auto;width:min(100%,460px);
  box-shadow:0 40px 90px #050b1f99, 0 0 0 1px #ffffff22;
}
.scene:before {
  content:"";position:absolute;inset:-12px;border-radius:212px 212px 36px 36px;
  border:1px solid #d8ad6555;pointer-events:none;
}
.scene-art {width:100%;height:100%;display:block}
.scene .sun {animation:rise 2.4s cubic-bezier(.2,.8,.2,1) both}
.scene .rays {animation:rays 40s linear infinite;transform-origin:220px 290px}
@keyframes rise {from{transform:translateY(120px);opacity:.3}to{transform:none;opacity:1}}
@keyframes rays {to{transform:rotate(360deg)}}
.scene-caption {
  position:absolute;left:0;right:0;bottom:64px;text-align:center;color:white;
  text-shadow:0 2px 12px #0e224699;
}
.scene-caption span {display:block;font:italic 600 26px var(--serif);color:#f7dfae}
.scene-caption strong {font:700 15px Outfit,sans-serif;letter-spacing:3px;text-transform:uppercase}
.float-card {
  position:absolute;background:#ffffffee;color:var(--navy);
  border-radius:16px;box-shadow:0 22px 50px #050b1f66;
  backdrop-filter:blur(12px);
  animation:float 7s ease-in-out infinite;
  transition:transform .3s;
}
a.float-card:hover {animation-play-state:paused;transform:translateY(-4px) scale(1.02)}
.score-card {top:58px;left:-6px;display:flex;align-items:center;gap:12px;padding:13px 18px 13px 13px}
.score-card small, .risks-card small {display:block;font-size:10px;font-weight:800;letter-spacing:1.5px;color:#8a95a8}
.score-card strong {font:700 14px Outfit,sans-serif;color:var(--purple)}
.mini-gauge {position:relative;width:44px;height:44px}
.mini-gauge svg {width:44px;height:44px;transform:rotate(-90deg)}
.mini-gauge .mg {animation:mg 2.5s .6s cubic-bezier(.2,.8,.2,1) forwards}
@keyframes mg {to{stroke-dashoffset:28}}
.mini-gauge b {position:absolute;inset:0;display:grid;place-items:center;font:800 16px Outfit,sans-serif;color:var(--navy)}
.risks-card {right:0;top:40%;padding:16px 20px;animation-delay:-2.5s;min-width:190px}
.risks-card ul {list-style:none;margin:8px 0 0;padding:0;display:grid;gap:6px;font-size:13px;font-weight:600}
.risks-card li {display:flex;align-items:center;gap:8px}
.risks-card i {width:16px;height:16px;border-radius:50%;background:#e8f6ef;position:relative;flex-shrink:0}
.risks-card i:after {content:"";position:absolute;left:5px;top:3px;width:4px;height:7px;border:solid #2f8a63;border-width:0 2px 2px 0;transform:rotate(45deg)}
.advisor-chip {left:0;bottom:-4px;display:flex;align-items:center;gap:12px;padding:10px 18px 10px 10px;animation-delay:-4.5s;border-radius:40px}
.advisor-chip img {width:44px;height:44px;border-radius:50%;border:2px solid var(--gold)}
.advisor-chip strong {display:block;font:700 14px Outfit,sans-serif}
.advisor-chip small {font-size:11.5px;color:#68758b}

/* Highlights */
.highlights {position:relative;z-index:2}
.highlight-grid {
  background:white;border-radius:20px;margin-top:-50px;
  box-shadow:var(--shadow-lg);border:1px solid var(--border);
}
.highlight {padding:28px 26px;justify-content:flex-start}
.highlight-icon {
  width:52px;height:52px;border-radius:14px;flex-shrink:0;display:grid;place-items:center;
  background:linear-gradient(135deg,#eaf1fb,#f7efe0);color:var(--navy);
}
.highlight-icon svg {width:24px;height:24px}
.highlights {background:var(--ivory);border:0}
.services {padding-top:90px}

/* Service cards */
.service-icon {width:62px;height:62px;border-radius:18px}
.service-icon svg {width:28px;height:28px}
.service-card {border-radius:22px}
.service-card:hover .service-icon {transform:rotate(-6deg) scale(1.06)}
.service-icon {transition:.35s}
.service-card a {color:var(--navy);display:inline-flex;align-items:center;gap:6px;border-bottom:2px solid var(--gold);padding-bottom:2px}

/* Risks */
.big-five {
  background:linear-gradient(180deg,var(--navy) 40%,#2b5596);
  -webkit-background-clip:text;background-clip:text;color:transparent;
  font-family:var(--serif);font-weight:700;
  line-height:1.1;
  padding:.06em .08em .04em 0;
  display:inline-block;
  overflow:visible;
}

/* Process */
.process {position:relative;overflow:hidden}
.process:before {
  content:"";position:absolute;inset:0;pointer-events:none;
  background-image:radial-gradient(#ffffff14 1px,transparent 1px);background-size:26px 26px;
  mask-image:linear-gradient(to bottom,transparent,#000 40%,transparent);
}
.steps {position:relative}
.steps:before {
  content:"";position:absolute;top:58px;left:16%;right:16%;height:2px;
  background:repeating-linear-gradient(90deg,#d8ad6588 0 10px,transparent 10px 20px);
}
.step {position:relative;background:linear-gradient(160deg,#1b3566,#132a57);transition:.35s}
.step:hover {border-color:#d8ad6588;transform:translateY(-6px)}
.step-top {display:flex;justify-content:space-between;align-items:center}
.step-no {font:italic 700 46px var(--serif);color:var(--gold)}
.step-icon {
  width:54px;height:54px;border-radius:50%;display:grid;place-items:center;
  background:var(--navy);border:2px solid #d8ad65;color:#f1d29a;position:relative;z-index:1;
}
.step-icon svg {width:24px;height:24px}

/* Quote / message: sunrise */
.message {
  position:relative;overflow:hidden;color:white;padding:120px 0 170px;
  background:
    radial-gradient(ellipse 60% 55% at 50% 105%,#f6d595 0%,#e9b97788 30%,transparent 70%),
    linear-gradient(180deg,#0e2246 0%,#24467f 60%,#3a5a95 100%);
}
.message-hills {position:absolute;left:0;right:0;bottom:-1px;width:100%;height:160px}
.message .quote-mark {color:var(--gold);font-family:var(--serif)}
.message h2 {font-family:var(--serif);font-style:italic;font-weight:500;letter-spacing:-.01em;color:white}
.message .signature {color:#f7dfae}
.message-panel {position:relative;z-index:1}

/* FAQ */
.faq-grid details {
  border:1px solid var(--border);border-radius:16px;padding:0 24px;margin-bottom:12px;
  background:white;transition:.3s;
}
.faq-grid details[open] {border-color:#bcd0ee;box-shadow:0 14px 34px #0e224610}
.faq-grid summary {
  list-style:none;padding:20px 0;display:flex;justify-content:space-between;align-items:center;gap:20px;
}
.faq-grid summary::-webkit-details-marker {display:none}
.faq-grid summary:after {
  content:"+";flex-shrink:0;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;
  background:#eaf1fb;color:var(--purple);font:700 20px/1 Outfit,sans-serif;transition:.3s;
}
.faq-grid details[open] summary:after {transform:rotate(45deg);background:var(--navy);color:white}
.faq-grid details p {padding-bottom:20px;margin-top:-4px}

/* Contact */
.contact-panel {
  background:
    radial-gradient(circle at 15% 0%,#d8ad6533,transparent 40%),
    radial-gradient(circle at 100% 100%,#2b559688,transparent 50%),
    var(--navy);
  box-shadow:0 40px 90px #0e224640;
}
.contact-cards {grid-template-columns:auto auto auto;justify-content:center}
.contact-cards a {white-space:nowrap;padding:14px 20px 14px 14px}
.contact-cards a span svg {width:17px;height:17px}

/* Footer */
footer {background:linear-gradient(180deg,#0b1c3c,#081530);border-top:3px solid var(--gold)}

/* Responsive for new pieces */
@media(max-width:1100px){
  .contact-cards {grid-template-columns:1fr;max-width:420px}
}
@media(max-width:950px){
  .scene-wrap {padding:20px 10px 30px;max-width:520px;margin:0 auto}
  .scene {margin:0 auto}
  .steps:before {display:none}
  .highlight-grid {margin-top:-30px}
}
@media(max-width:550px){
  .eyebrow:before, .center .eyebrow:after {display:none}
  .brand-logo {height:44px}
  .scene-wrap {padding:10px 0 20px}
  .score-card {top:24px;left:-4px;padding:10px 14px 10px 10px}
  .risks-card {display:none}
  .scene {width:100%}
  .advisor-chip {bottom:0}
  .scene-caption {bottom:70px}
  .scene-caption span {font-size:21px}
  .contact-cards a {white-space:normal}
}

/* Service photos */
.service-card {padding:0 0 32px}
.service-card > *:not(.service-media) {margin-left:32px;margin-right:32px}
.service-media {position:relative;aspect-ratio:16/9;overflow:hidden;background:#e9edf4}
.service-grid.five .service-card:nth-child(n+4) .service-media {aspect-ratio:21/9}
.service-media img {width:100%;height:100%;object-fit:cover;display:block;color:transparent;font-size:0;transition:transform .7s cubic-bezier(.2,.8,.2,1)}
.service-media:after {content:"";position:absolute;inset:0;background:linear-gradient(180deg,transparent 55%,#0e224633)}
.service-card:hover .service-media img {transform:scale(1.06)}
.service-card .service-icon {position:relative;z-index:1;margin-top:-31px;background:white!important;box-shadow:0 12px 28px #0e224626;border:1px solid var(--border)}
.service-card h3 {margin-top:20px}
@media(max-width:950px){.service-grid.five .service-card:nth-child(n+4) .service-media {aspect-ratio:16/9}}

/* Real sunrise photo in hero */
.scene {background:#0e2246}
.scene-art {width:100%;height:100%;object-fit:cover;object-position:50% 30%;transform:scale(1.3);transform-origin:100% 35%;filter:saturate(1.35) contrast(1.12) brightness(1.04);animation:kenburns 22s ease-in-out infinite alternate}
@keyframes kenburns {from{transform:scale(1.28)}to{transform:scale(1.4)}}
.scene-shade {position:absolute;inset:0;pointer-events:none;
  background:linear-gradient(180deg,transparent 0%,transparent 58%,#0e2246b3 100%)}
@keyframes glow {from{opacity:.85}to{opacity:1}}

/* Whole service card is clickable (stretched link) */
.service-card {position:relative;cursor:pointer}
.service-card a[data-risk]:after {content:"";position:absolute;inset:0;z-index:2;border-radius:inherit}
.service-card a[data-risk]:focus-visible {outline:none}
.service-card:has(a[data-risk]:focus-visible) {outline:3px solid var(--gold);outline-offset:3px}
.service-card:hover a[data-risk] {color:var(--purple)}

/* Trust badges & photos */
.brand-logo {height:58px}
footer .brand-logo {height:70px}
.trust-row {display:flex;flex-wrap:wrap;align-items:center;gap:16px;margin:0 0 26px}
.bbb-link {display:block;border-radius:10px;transition:.3s;line-height:0}
.bbb-link img {height:58px;width:auto;display:block}
.bbb-link:hover {transform:translateY(-2px);box-shadow:0 10px 24px #0e224622}
.contact-card {display:flex;align-items:center;gap:12px;padding:8px 16px 8px 8px;border:1px solid var(--border);border-radius:14px;background:white}
.contact-card img {width:64px;height:64px;display:block}
.contact-card strong {display:block;font:700 14px Outfit,sans-serif;color:var(--navy)}
.contact-card small {font-size:12.5px;color:var(--muted)}
.contact-card a {color:var(--purple);font-weight:700}
.footer-bbb {display:inline-block;margin-top:22px;background:white;border-radius:12px;padding:8px;line-height:0;transition:.3s}
.footer-bbb img {height:96px;width:auto}
.footer-bbb:hover {transform:translateY(-3px)}
.advisor-photo {border:none;background:transparent;box-shadow:0 30px 70px #0006;border-radius:50%}
.process-photos {display:grid;grid-template-columns:1fr 2fr;gap:18px;margin:0 0 50px;position:relative;z-index:1}
.process-photos figure {margin:0;position:relative;border-radius:20px;overflow:hidden;height:340px;border:1px solid #ffffff22}
.process-photos img {width:100%;height:100%;object-fit:cover;display:block;transition:transform .8s cubic-bezier(.2,.8,.2,1)}
.process-photos figure:hover img {transform:scale(1.05)}
.process-photos figcaption {position:absolute;left:16px;bottom:16px;background:#0e2246cc;color:#fff;font:600 12px Outfit,sans-serif;letter-spacing:1.5px;text-transform:uppercase;padding:8px 12px;border-radius:30px;backdrop-filter:blur(6px)}
.process-photos figure:first-child img {object-position:50% 25%}
@media(max-width:800px){.process-photos{grid-template-columns:1fr}.process-photos figure{height:260px}.process-photos figure:first-child img{object-position:50% 52%}}
@media(max-width:550px){.brand-logo{height:46px}}

/* Green pastures hero + bio */
.scene-art {object-position:50% 62% !important;transform:none !important;filter:saturate(1.18) contrast(1.06) brightness(1.22) !important;animation:kenburns2 26s ease-in-out infinite alternate !important;transform-origin:50% 70%}
@keyframes kenburns2 {from{transform:scale(1)}to{transform:scale(1.08)}}
.scene-shade {background:linear-gradient(180deg,transparent 0%,transparent 48%,#0e2246b8 78%,#0e2246d9 100%) !important}
.scene-caption {bottom:78px !important;left:26px !important;right:26px !important;text-align:center}
.scene-title {margin:0;font:italic 600 27px/1.18 var(--serif);color:#f7dfae;letter-spacing:-.01em;text-shadow:0 2px 14px #0e2246aa}
.scene-sub {margin:10px auto 0;max-width:340px;font:500 13.5px/1.5 Outfit,sans-serif;color:#e6ecf6}
.risks-card {top:22% !important}
.cred-row {display:flex;flex-wrap:wrap;gap:8px;margin:4px 0 18px}
.cred-row span {font-size:12.5px;font-weight:700;color:var(--navy);background:#eaf1fb;border-radius:20px;padding:7px 12px}
.advisor-quote {margin:0 0 22px;padding:14px 18px;border-left:3px solid var(--gold);background:#fbf7ef;border-radius:0 12px 12px 0;font:italic 600 17px/1.45 var(--serif);color:var(--navy)}
.advisor-quote cite {display:block;margin-top:6px;font:600 12px Outfit,sans-serif;font-style:normal;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted)}
.checkup {background:linear-gradient(180deg,#0b2d63eb 0%,#0e2246f2 60%,#0e2246fa 100%),url(<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-checkup-stethoscope.webp) center/cover no-repeat !important}
@media(max-width:550px){.scene-title{font-size:22px}.scene-sub{font-size:12.5px}.scene-caption{bottom:74px !important}}

/* Hero info panel below the arch (keeps the photo unobstructed) */
.scene-wrap {padding:24px 0 10px !important;display:flex;flex-direction:column;align-items:flex-end;gap:14px}
.scene {max-height:430px !important;margin-left:auto}
.scene-caption {bottom:34px !important}
.scene-info {width:min(100%,460px);display:grid;grid-template-columns:1fr 1fr;gap:10px}
.info-card {background:#ffffffee;color:var(--navy);border-radius:16px;box-shadow:0 16px 36px #050b1f55;transition:transform .3s, box-shadow .3s}
a.info-card:hover {transform:translateY(-3px);box-shadow:0 22px 44px #050b1f66}
.info-score {display:flex;align-items:center;gap:12px;padding:12px 14px 12px 12px}
.info-score small, .info-risks small {display:block;font-size:9.5px;font-weight:800;letter-spacing:1.4px;color:#7d889b}
.info-score strong {font:700 15px Outfit,sans-serif;color:var(--purple);white-space:nowrap}
.info-advisor {display:flex;align-items:center;gap:10px;padding:10px 14px 10px 10px}
.info-advisor img {width:44px;height:44px;border-radius:50%;border:2px solid var(--gold);flex-shrink:0}
.info-advisor strong {display:block;font:700 14px Outfit,sans-serif}
.info-advisor small {font-size:11.5px;color:#68758b}
.info-risks {grid-column:1 / -1;padding:11px 12px}
.info-risks ul {list-style:none;margin:8px 0 0;padding:0;display:flex;flex-wrap:wrap;gap:6px}
.info-risks a {display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:var(--navy);background:#eef3fa;border-radius:20px;padding:6px 11px 6px 8px;transition:.2s}
.info-risks a:before {content:"✓";display:grid;place-items:center;width:15px;height:15px;border-radius:50%;background:#e1f3ea;color:#2f8a63;font-size:9.5px;font-weight:800}
.info-risks a:hover {background:var(--navy);color:#fff}
@media(max-width:950px){.scene-wrap{align-items:center}.scene{margin:0 auto}}
@media(max-width:550px){.scene-info{grid-template-columns:1fr}.info-risks a{font-size:12px}}

/* Advisor section layout fix + bio dialog */
.about-grid {align-items:start !important}
.advisor-open {position:sticky;top:120px;width:100%;border:0;padding:0;font:inherit;color:inherit;text-align:inherit;cursor:pointer;min-height:500px}
.advisor-open .advisor-photo {transition:transform .5s cubic-bezier(.2,.8,.2,1)}
.advisor-open:hover .advisor-photo {transform:scale(1.04)}
.advisor-open:focus-visible {outline:3px solid var(--gold);outline-offset:4px}
.bio-hint {position:absolute;right:24px;bottom:24px;z-index:2;display:inline-flex;gap:6px;align-items:center;background:var(--gold);color:var(--navy);font:700 13px Outfit,sans-serif;padding:10px 16px;border-radius:30px;box-shadow:0 10px 24px #0005;transition:.3s}
.advisor-open:hover .bio-hint {transform:translateY(-3px)}
.read-bio {background:none;border:0;padding:0;margin:-6px 0 18px;font:700 15px Outfit,sans-serif;color:var(--purple);cursor:pointer;border-bottom:2px solid var(--gold)}
.read-bio:hover {color:var(--navy)}
.bio-dialog {border:0;padding:0;border-radius:24px;max-width:980px;width:calc(100% - 32px);max-height:calc(100vh - 48px);box-shadow:0 40px 100px #050b1f99;color:var(--text)}
.bio-dialog::backdrop {background:#0b1730c7;backdrop-filter:blur(4px)}
.bio-dialog[open] {animation:bioIn .35s cubic-bezier(.2,.8,.2,1)}
@keyframes bioIn {from{opacity:0;transform:translateY(18px) scale(.98)}to{opacity:1;transform:none}}
.bio-shell {display:grid;grid-template-columns:300px 1fr;position:relative}
.bio-close {position:absolute;right:14px;top:12px;z-index:2;width:40px;height:40px;border-radius:50%;border:0;background:#eef1f6;color:var(--navy);font-size:26px;line-height:1;cursor:pointer}
.bio-close:hover {background:var(--navy);color:#fff}
.bio-side {background:linear-gradient(160deg,#16305e,#2b5596);color:#fff;padding:36px 28px;text-align:center}
.bio-side > img {width:180px;height:180px;border-radius:50%;display:block;margin:0 auto 16px;box-shadow:0 18px 40px #0006}
.bio-side h2 {margin:0;font-size:26px;color:#fff}
.bio-role {margin:4px 0 0;color:#f1d29a;font-weight:600;font-size:14px}
.bio-firm {margin:10px 0 18px;color:#c9d3e6;font-size:13.5px;line-height:1.5}
.bio-creds {list-style:none;margin:0 0 20px;padding:0;display:grid;gap:8px;text-align:left}
.bio-creds li {background:#ffffff14;border:1px solid #ffffff26;border-radius:12px;padding:9px 12px 9px 34px;font-size:13px;position:relative}
.bio-creds li:before {content:"✓";position:absolute;left:12px;color:#f1d29a;font-weight:800}
.bio-bbb {display:inline-block;background:#fff;border-radius:10px;padding:6px;line-height:0}
.bio-bbb img {height:46px;width:auto}
.bio-main {padding:40px 40px 34px;overflow:auto}
.bio-main h3 {font-family:var(--serif);font-size:30px;line-height:1.15;color:var(--navy);margin:6px 50px 14px 0}
.bio-main h4 {font-size:17px;color:var(--navy);margin:22px 0 6px}
.bio-main p {color:var(--muted);line-height:1.75;margin:0 0 12px;font-size:15.5px}
.bio-help {list-style:none;padding:0;margin:8px 0 22px;display:grid;grid-template-columns:1fr 1fr;gap:8px}
.bio-help li {background:#eaf1fb;color:var(--navy);font-weight:600;font-size:14px;border-radius:12px;padding:10px 12px}
.bio-actions {display:flex;flex-wrap:wrap;gap:10px;margin-top:6px}
.bio-actions .btn {padding:13px 18px;font-size:14px}
@media(max-width:800px){.bio-shell{grid-template-columns:1fr}.bio-side{padding:30px 22px}.bio-main{padding:28px 22px}.bio-main h3{font-size:24px;margin-right:0}.advisor-open{position:relative;top:0;min-height:430px}.bio-hint{top:16px;left:16px;right:auto;bottom:auto;padding:8px 13px;font-size:12px}.bio-help{grid-template-columns:1fr}}

/* Six service cards: clean 3x2 grid */
.service-grid.six {grid-template-columns:repeat(3,minmax(0,1fr));align-items:stretch}
.service-grid.six .service-card {grid-column:auto !important;display:flex;flex-direction:column}
.service-grid.six .service-card > a {margin-top:auto;align-self:flex-start}
.service-grid.six .service-media {aspect-ratio:16/10 !important}
.svc-tag {margin:-4px 0 8px;font:italic 600 16px var(--serif);color:#a87a2f}
.svc-short {font-weight:600;color:var(--navy) !important}
.service-card a.svc-link {color:var(--navy);display:inline-flex;align-items:center;gap:6px;border-bottom:2px solid var(--gold);padding-bottom:2px;font-weight:700}
.service-card a.svc-link:after {content:"";position:absolute;inset:0;z-index:2;border-radius:inherit}
.service-media img {image-rendering:auto}
@media(max-width:1000px){.service-grid.six{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:640px){.service-grid.six{grid-template-columns:1fr}}
/* Safe Money seal */
.seal-badge {position:absolute;right:20px;top:20px;width:104px;height:104px;z-index:2;filter:drop-shadow(0 10px 20px #0006)}
.seal-inline {height:62px;width:62px}
.bio-seal {display:block;width:110px;height:110px;margin:0 auto 14px;background:#fff;border-radius:50%;padding:4px}
@media(max-width:800px){.seal-badge{width:78px;height:78px;right:14px;top:14px}}

/* Health Check lead form + delivery */
.lead-form {margin-top:4px;padding:20px;border:1px solid var(--border);border-radius:16px;background:#fbfaf7}
.lead-title {margin:0 0 12px !important;font:700 15px Outfit,sans-serif;color:var(--navy)}
.lead-grid {display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
.lead-grid label {display:flex;flex-direction:column;gap:6px;font-size:13px;font-weight:700;color:var(--navy)}
.lead-grid label span {font-weight:500;color:var(--muted)}
.lead-grid input {font:500 15px "DM Sans",sans-serif;padding:12px 13px;border:1.5px solid var(--border);border-radius:11px;background:#fff;color:var(--text);min-height:46px}
.lead-grid input:focus {outline:none;border-color:var(--purple);box-shadow:0 0 0 3px #1f5bb522}
.consent {display:flex;gap:10px;align-items:flex-start;margin:14px 0 6px;font-size:12.5px;line-height:1.55;color:var(--muted);cursor:pointer}
.consent input {width:18px;height:18px;margin-top:2px;flex-shrink:0;accent-color:var(--navy)}
.hp {position:absolute !important;left:-9999px;width:1px;height:1px;overflow:hidden}
.lead-error {min-height:18px;margin:4px 0 10px !important;color:#b4537b !important;font-size:13px;font-weight:600}
.deliver {margin-top:18px;padding:12px 16px;border-radius:12px;background:#eef3fa;color:var(--navy);font-size:14px;line-height:1.5;display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.deliver.ok {background:#e8f6ef;color:#1f6b4b}
.deliver.warn {background:#fbf2e2;color:#7a5520}
.deliver .link-btn {padding:0;margin-left:4px;text-decoration:underline}
.spin {width:14px;height:14px;border:2px solid #1f5bb544;border-top-color:#1f5bb5;border-radius:50%;display:inline-block;animation:spin .8s linear infinite}
@keyframes spin {to{transform:rotate(360deg)}}
@media(max-width:700px){.lead-grid{grid-template-columns:1fr}}

.lead-grid label {justify-content:flex-end}
.checkup-side .qr-box {flex-direction:column;align-items:flex-start;text-align:left}
</style>
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/vendor/jspdf.umd.min.js" defer></script>
<script>window.NFS_API = { url: <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?> };</script>
</head>

<body>

<div class="announce">
  <div class="container">
    <span><span class="dot"></span>Free Financial Protection Health Check<span class="hide-sm"> · 2–3 minutes · No obligation</span></span>
    <a href="#checkup">Get your score →</a>
    <span class="hide-sm">Call <a href="tel:+15392377273">(539) 237-7273</a></span>
  </div>
</div>

<header>
  <nav class="nav container">
    <a href="#home" class="logo" aria-label="Noble Finance Solutions home">
      <img class="brand-logo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/noble-logo-official-light.png" alt="Noble Finance Solutions" width="1207" height="559">
    </a>

    <div class="nav-links" id="navLinks">
      <a href="#services">Services</a>
      <a href="#risks">5 Risks</a>
      <a href="#checkup">Health Check</a>
      <a href="#about">Meet Maunty</a>
      <a href="#contact" class="btn btn-gold">Book a Review ↗</a>
    </div>

    <button class="menu" id="menuBtn" aria-label="Open menu" aria-expanded="false" aria-controls="navLinks">☰</button>
  </nav>
</header>

<main>

<!-- HERO -->

<section id="home" class="hero">
  <div class="container hero-grid">

    <div class="reveal">
      <div class="motto" aria-label="Educate, Plan, Protect, Empower">
        <span>EDUCATE</span><span>PLAN</span><span>PROTECT</span><span>EMPOWER</span>
      </div>

      <h1>
        Your Future.<br>
        Your Legacy.<br>
        <span class="serif-accent">Our Priority.</span>
      </h1>

      <p>
        Education-driven financial guidance for families, retirees,
        and business owners in Tulsa County and surrounding areas.
        Clear information. Practical options. No one-size-fits-all approach.
      </p>

      <div class="hero-buttons">
        <a href="#checkup" class="btn btn-gold">
          Take the Free Health Check ↗
        </a>
        <a href="#services" class="btn btn-outline">
          Explore Our Services
        </a>
      </div>

      <div class="hero-trust">
        <span class="trust-icon">✓</span>
        Real solutions for life's “what ifs.”
      </div>
    </div>

    <div class="scene-wrap reveal">
      <div class="scene">
        <img class="scene-art" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-green-pastures.jpg" alt="A quiet road winding through green pastures toward the mountains" width="1600" height="1600" fetchpriority="high">
        <div class="scene-shade"></div>
        <div class="scene-caption">
          <h2 class="scene-title">Peace of Mind on the Road to Greener Pastures.</h2>
          <p class="scene-sub">Robust insurance strategies that safeguard your wealth, your workforce, and your legacy.</p>
        </div>
      </div>

      <div class="scene-info">
        <a href="#checkup" class="info-card info-score">
          <div class="mini-gauge">
          <svg viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="18" fill="none" stroke="#eef0f5" stroke-width="5"/><circle class="mg" cx="22" cy="22" r="18" fill="none" stroke="#d8ad65" stroke-width="5" stroke-linecap="round" stroke-dasharray="113" stroke-dashoffset="113"/></svg>
          <b>?</b>
        </div>
          <div><small>FREE · 2 MINUTES</small><strong>Get your score →</strong></div>
        </a>
        <a href="#about" class="info-card info-advisor">
          <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/maunty-wright.webp" alt="" width="44" height="44">
          <div><strong>Maunty Wright</strong><small>Your Tulsa advisor</small></div>
        </a>
        <div class="info-card info-risks">
          <small>5 RISKS WORTH PLANNING FOR</small>
          <ul>
            <li><a href="#risks" data-risk="0">Life insurance</a></li>
            <li><a href="#risks" data-risk="1">Retirement income</a></li>
            <li><a href="#risks" data-risk="2">Long-term care</a></li>
            <li><a href="#risks" data-risk="3">Debt protection</a></li>
            <li><a href="#risks" data-risk="4">Final expense</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- HIGHLIGHTS -->

<section class="highlights">
  <div class="container highlight-grid">
    <div class="highlight">
      <span class="highlight-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/></svg></span>
      <div>
        <strong>Clear Information</strong>
        <small>Education before any decision</small>
      </div>
    </div>

    <div class="highlight">
      <span class="highlight-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/></svg></span>
      <div>
        <strong>Practical Options</strong>
        <small>Personalized coverage built around you</small>
      </div>
    </div>

    <div class="highlight">
      <span class="highlight-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg></span>
      <div>
        <strong>No One-Size-Fits-All</strong>
        <small>Your family, your plan</small>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES -->

<section class="section services" id="services">
  <div class="container">
    <div class="center reveal">
      <div class="eyebrow">WHAT WE OFFER</div>
      <h2>Personalized Coverage Solutions<br>Built Around Your Needs.</h2>
      <p class="section-intro">
        Six areas where a little planning today can make a big
        difference for the people you love. Tap any card to see
        the risk behind it.
      </p>
    </div>

    <div class="service-grid six">

      <article class="service-card reveal">
        <div class="service-media"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-family.jpg" alt="Three generations of a smiling family together outdoors" loading="lazy" decoding="async"></div>
        <div class="service-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg></div>
        <h3>Life Insurance</h3>
        <p class="svc-tag">Peace of Mind, Policy in Hand</p>
        <p class="svc-short">A flexible coverage plan that&rsquo;s customized to fit your unique financial needs and future goals.</p>
        <p>Build a foundation that empowers you to thrive from this day forward. Customizable coverage provides a reliable bridge, ensuring your mortgage stays paid and your children&rsquo;s college funds remain secure through a powerful financial engine that safeguards your household today and guarantees a tax-free legacy they can always depend on.</p>
        <span class="stat-chip">40% of U.S. adults say they need more</span><br>
        <a href="#risks" data-risk="0" aria-label="Life Insurance: see the risk">See the risk ↗</a>
      </article>

      <article class="service-card reveal">
        <div class="service-media"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-retirement-couple.jpg" alt="A smiling retired couple sitting close together outdoors" loading="lazy" decoding="async"></div>
        <div class="service-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/></svg></div>
        <h3>Retirement Income</h3>
        <p class="svc-tag">Retire Confident, Live Fully</p>
        <p class="svc-short">Strategies designed to create a reliable, tax-efficient income stream that lasts as long as you do.</p>
        <p>Securing your financial freedom in your next chapter requires a reliable strategy that transforms your hard-earned savings into a predictable paycheck. A robust retirement income product provides guaranteed monthly payments, protects your nest egg from market volatility, and ensures you never outlive your money.</p>
        <span class="stat-chip">Only 57% think savings will last</span><br>
        <a href="#risks" data-risk="1" aria-label="Retirement Income: see the risk">See the risk ↗</a>
      </article>

      <article class="service-card reveal">
        <div class="service-media"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-caregiver.jpg" alt="A caregiver sharing a warm moment with an older woman in a wheelchair" loading="lazy" decoding="async"></div>
        <div class="service-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7Z"/></svg></div>
        <h3>Long-Term Care</h3>
        <p class="svc-tag">Preserve Dignity and Independence</p>
        <p class="svc-short">Thoughtful coverage designed to protect your savings, independence, and your family&rsquo;s financial stability.</p>
        <p>Long-term care protection can help provide financial support for services such as in-home care, assisted living, and skilled nursing care, helping reduce the emotional and financial burden on loved ones. The right strategy can help preserve your assets, protect your retirement income, and maintain greater control over how and where care is received.</p>
        <span class="stat-chip">~70% chance of needing care after 65</span><br>
        <a href="#risks" data-risk="2" aria-label="Long-Term Care: see the risk">See the risk ↗</a>
      </article>

      <article class="service-card reveal">
        <div class="service-media"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-home-keys.webp" alt="A model house with house keys and a notebook on a desk" loading="lazy" decoding="async"></div>
        <div class="service-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/></svg></div>
        <h3>Debt Protection</h3>
        <p>
          Don't leave debt behind. A protection strategy can help keep
          your mortgage and other obligations from becoming a family burden.
        </p>
        <span class="stat-chip">U.S. household debt: $18.8 trillion</span><br>
        <a href="#risks" data-risk="3" aria-label="Debt Protection: see the risk">See the risk ↗</a>
      </article>

      <article class="service-card reveal">
        <div class="service-media"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-sunrise-path.jpg" alt="A quiet path through green fields toward a golden sunrise" loading="lazy" decoding="async"></div>
        <div class="service-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="2.5"/><path d="M12 9.5C10 7 10 4 12 2c2 2 2 5 0 7.5M14.5 12c2.5-2 5.5-2 7.5 0-2 2-5 2-7.5 0M12 14.5c2 2.5 2 5.5 0 7.5-2-2-2-5 0-7.5M9.5 12C7 14 4 14 2 12c2-2 5-2 7.5 0"/></svg></div>
        <h3>Final Expense</h3>
        <p>
          Funds set aside for end-of-life costs, easing the burden
          on your loved ones during an already difficult time.
        </p>
        <span class="stat-chip">Funerals can exceed $8,000</span><br>
        <a href="#risks" data-risk="4" aria-label="Final Expense: see the risk">See the risk ↗</a>
      </article>

      <article class="service-card reveal">
        <div class="service-media"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-employee-benefits.jpg" alt="A smiling team of workers in a manufacturing facility" loading="lazy" decoding="async"></div>
        <div class="service-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg></div>
        <h3>Employee Benefits</h3>
        <p class="svc-tag">Protect Your Team, Grow Your Business</p>
        <p>Protecting your team is one of the smartest investments a business owner can make. Our employee benefits solutions are designed to help small and mid-sized businesses attract and retain top talent &mdash; offering life insurance, health coverage, and supplemental benefits that give your employees real peace of mind. We work with business owners to build customized benefits packages that fit their budget and their team&rsquo;s needs, because when your people feel protected, your business thrives.</p>
        <span class="stat-chip">For small &amp; mid-sized businesses</span><br>
        <a href="mailto:contact@noblefinancesolutions.com?subject=Employee%20Benefits" class="svc-link" aria-label="Employee Benefits: talk to Maunty">Talk to Maunty ↗</a>
      </article>

    </div>
  </div>
</section>

<!-- 5 FINANCIAL RISKS -->

<section class="section risks" id="risks">
  <div class="container">
    <div class="risks-head reveal">
      <div class="big-five" aria-hidden="true">5</div>
      <div>
        <div class="eyebrow">REAL SOLUTIONS FOR LIFE'S WHAT IFS</div>
        <h2>Financial Risks <em>Worth Planning For.</em></h2>
        <p>Life is full of <b>what ifs</b>. A little planning today can help you and your family face tomorrow with more confidence.</p>
      </div>
    </div>

    <div class="risk-explorer reveal" id="riskExplorer">
      <div class="risk-tabs" role="tablist" aria-label="Five financial risks"></div>

      <div class="risk-panel" id="riskPanel" role="tabpanel" aria-live="polite">
        <div class="risk-photo" id="riskPhoto">
          <div class="badge-num" id="riskNum">1</div>
          <div class="stat-ring">
            <svg viewBox="0 0 100 100" aria-hidden="true">
              <circle class="ring-bg" cx="50" cy="50" r="42" fill="none" stroke-width="9"/>
              <circle class="ring-fg" id="ringFg" cx="50" cy="50" r="42" fill="none" stroke-width="9" stroke-dasharray="263.9" stroke-dashoffset="263.9"/>
            </svg>
            <div>
              <div class="stat-value" id="statValue">0%</div>
              <div class="stat-label" id="statLabel"></div>
            </div>
          </div>
        </div>

        <div class="risk-body">
          <div class="eyebrow" id="riskEyebrow">RISK 1 OF 5</div>
          <h3 id="riskTitle"></h3>
          <div class="key-fact"><b>Key Fact:</b> <span id="riskFact"></span></div>
          <p id="riskText"></p>
          <div class="ask">
            <div class="ask-title"><span>?</span> Ask yourself</div>
            <ul id="riskQuestions"></ul>
          </div>
          <div class="risk-actions">
            <a href="#checkup" class="btn btn-dark">Check my score ↗</a>
            <a href="#contact" class="btn btn-ghost" id="riskTalk">Talk it through</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FREE FINANCIAL PROTECTION HEALTH CHECK -->

<section class="section checkup" id="checkup">
  <div class="container">
    <div class="center reveal" style="margin-bottom:50px">
      <div class="eyebrow">FREE FINANCIAL PROTECTION HEALTH CHECK</div>
      <h2>How Financially Prepared<br>Is Your Household?</h2>
      <p class="section-intro" style="color:#c2cbdd">
        Answer 10 quick questions to get your Financial Protection Score
        and a snapshot of your long-term financial health.
      </p>
    </div>

    <div class="checkup-grid">
      <div class="quiz-card reveal" id="quiz" aria-live="polite"></div>

      <aside class="checkup-side reveal">
        <div class="side-card">
          <div class="qr-box">
            <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/checkup-qr-noble.png" alt="QR code for the Financial Protection Health Check" width="112" height="112">
            <div>
              <h3>On your phone?</h3>
              <p>Scan to take the checkup on the go, or share it with your spouse.</p>
              <a href="https://hqr.la/1f159ada" target="_blank" rel="noopener noreferrer">Open the full checkup ↗</a>
            </div>
          </div>
        </div>
        <div class="side-card">
          <div class="privacy">
            <span>🔒</span>
            <div>
              <h3>Your information stays private</h3>
              <p>Your details and results go only to you and Maunty, so he can follow up. Your information is never sold or shared.</p>
            </div>
          </div>
        </div>
        <div class="side-card">
          <h3>2–3 minutes · Free · No obligation</h3>
          <p>Covers the five risks most families overlook: life insurance, retirement income, long-term care, debt and final expenses.</p>
        </div>
      </aside>
    </div>

    <p class="disclaimer">
      This checkup is for educational purposes and provides a general snapshot
      based on your responses. It is not a comprehensive financial, insurance,
      investment, tax, or legal analysis.
    </p>
  </div>
</section>

<!-- ABOUT -->

<section class="section" id="about">
  <div class="container about-grid">

    <button type="button" class="about-visual advisor-visual advisor-open reveal" data-open-bio aria-haspopup="dialog" aria-controls="bioDialog">
      <div class="orbit"></div>
      <div class="orbit two"></div>
      <div class="orbit three"></div>
      <img class="advisor-photo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/maunty-wright.webp" alt="Portrait of Maunty Wright, Life Insurance Broker and Finance Professional" width="320" height="320" loading="lazy">
      <div class="name-card">
        <strong>Maunty Wright</strong>
        <small>Life Insurance Broker &amp; Finance Professional</small>
      </div>
      <span class="bio-hint">View full bio <span aria-hidden="true">→</span></span>
    </button>

    <div class="about-text reveal">
      <div class="eyebrow">MEET YOUR ADVISOR</div>
      <h2>Education Driven<br><span style="color:#1f5bb5">Financial Guidance.</span></h2>

      <div class="service-area">📍 Tulsa County &amp; surrounding areas</div>

      <p>
        Tulsa-raised and education-first, Maunty Wright founded Noble Finance
        Solutions to help local families, retirees, and business owners protect what
        they&rsquo;ve built, with clear information and a realistic plan, never
        products you don&rsquo;t need.
      </p>
      <button type="button" class="read-bio" data-open-bio aria-haspopup="dialog" aria-controls="bioDialog">Read Maunty&rsquo;s full story <span aria-hidden="true">→</span></button>

      <div class="cred-row">
        <span>Life Insurance Broker &amp; Finance Professional</span>
        <span>8+ years of experience</span>
        <span>SafeMoney Certified&trade;</span>
        <span>NPN #22312170</span>
      </div>


      <div class="pillars">
        <div class="pillar"><span>1</span><div><strong>Flexible, customized coverage plans</strong><small>Secure your income, protect what matters, plan for what's next.</small></div></div>
        <div class="pillar"><span>2</span><div><strong>Prepare for the future</strong><small>Tax-smart retirement strategies, built so you never outlive your money.</small></div></div>
        <div class="pillar"><span>3</span><div><strong>Preserve dignity and independence</strong><small>Thoughtful coverage built around dignity, choice and long-term security.</small></div></div>
      </div>

      <div class="trust-row">
        <img class="seal-inline" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/safe-money-certified.png" alt="Safe Money Certified" width="464" height="464">
        <a class="bbb-link" href="https://www.bbb.org/us/ok/tulsa/profile/insurance-agency/noble-finance-solutions-1025-38111690/#sealclick" target="_blank" rel="noopener noreferrer" aria-label="Noble Finance Solutions is a BBB Accredited Business: view the BBB profile">
          <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/bbb-accredited-horizontal.png" alt="BBB Accredited Business" width="448" height="160">
        </a>
        <div class="contact-card">
          <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/maunty-contact-qr.png" alt="QR code to save Maunty Wright's digital business card" width="84" height="84">
          <div><strong>Save Maunty&rsquo;s contact</strong><small>Scan, or <a href="https://s.blinq.me/A1pbR0qX7BKX" target="_blank" rel="noopener noreferrer">open his digital card ↗</a></small></div>
        </div>
      </div>

      <a href="#contact" class="btn btn-purple">
        Book Your Review With Maunty ↗
      </a>
    </div>

  </div>
</section>

<dialog class="bio-dialog" id="bioDialog" aria-labelledby="bioTitle">
  <div class="bio-shell">
    <button type="button" class="bio-close" data-close-bio aria-label="Close bio">&times;</button>
    <aside class="bio-side">
      <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/maunty-wright.webp" alt="Portrait of Maunty Wright" width="220" height="220">
      <h2 id="bioTitle">Maunty Wright</h2>
      <p class="bio-role">Life Insurance Broker &amp; Finance Professional</p>
      <p class="bio-firm">Founder, Noble Finance Solutions<br>Tulsa, Oklahoma</p>
      <ul class="bio-creds">
        <li>Life Insurance Broker &amp; Finance Professional</li>
        <li>8+ years of experience</li>
        <li>SafeMoney Certified&trade;</li>
        <li>NPN #22312170</li>
      </ul>
      <img class="bio-seal" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/safe-money-certified.png" alt="Safe Money Certified" width="464" height="464">
      <a class="bio-bbb" href="https://www.bbb.org/us/ok/tulsa/profile/insurance-agency/noble-finance-solutions-1025-38111690/#sealclick" target="_blank" rel="noopener noreferrer"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/bbb-accredited-horizontal.png" alt="BBB Accredited Business" width="448" height="160"></a>
    </aside>
    <div class="bio-main">
      <div class="eyebrow">MEET YOUR ADVISOR</div>
      <h3>In Maunty&rsquo;s words</h3>
      <p>At Noble Finance Solutions, I believe that protecting your family and securing your future shouldn&rsquo;t be complicated or reserved for the wealthy.</p>
      <p>My story starts in Tulsa, Oklahoma, where I learned early that real wealth isn&rsquo;t just about what you earn &mdash; it&rsquo;s about what you protect. My first teacher was my mother. She built a strong financial foundation the hard way through steady work, strict saving, and disciplined budgeting. Those early life lessons gave me profound respect for hard work and dedication. It also prompted a lasting question: what becomes possible when discipline is paired with sound financial strategy?</p>
      <p>That question followed me to Southern California, where I began my career in television and film. I spent over 15 years building a solid career in entertainment, and along the way I was quietly doing something most people in that industry weren&rsquo;t: studying money. I was learning the principles of wealth-building, financial literacy, and managing my finances with intention long before it became my profession.</p>
      <p>Following the disruptions of COVID-19 that led to the industry downturn, and the accelerating shift toward artificial intelligence, work slowed and uncertainty increased. Like many people, I found myself trying to adapt to a changing economy &mdash; the transition into financial services wasn&rsquo;t a leap of faith. It was a natural next step. Soon into my career transition, life reminded me what really matters. A death in my family brought me back to my roots in Tulsa, Oklahoma, where I found a community full of hardworking families and business owners who needed exactly what I had spent years preparing to offer. Noble Finance Solutions was built to serve them.</p>
      <p>I&rsquo;m a finance professional with a primary focus in life insurance, retirement income, and long-term care protection &mdash; three essential pillars that help families protect what they&rsquo;ve built, prepare for future income needs, and plan with greater confidence. Providing solutions that prevent financial devastation for my clients makes this work incredibly rewarding. When clients tell me they finally have peace of mind, or that they&rsquo;re sleeping better at night knowing their family is protected &mdash; that&rsquo;s when I know I&rsquo;m truly being of service. I often feel like I&rsquo;m answering a higher calling in a way my previous career never did.</p>
      <p>Instead of overwhelming you with jargon or unneeded products, I will educate and guide you to a clear, realistic plan you can execute with confidence.</p>
      <h4>How he can help</h4>
      <ul class="bio-help">
        <li>Life insurance</li>
        <li>Retirement income planning</li>
        <li>Annuities (fixed &amp; indexed)</li>
        <li>Long-term care planning</li>
        <li>Employee benefits</li>
        <li>Final expense &amp; debt protection</li>
      </ul>
      <blockquote class="advisor-quote">&ldquo;Your legacy starts with protection. Let&rsquo;s build it together.&rdquo;<cite>Maunty Wright</cite></blockquote>
      <div class="bio-actions">
        <a class="btn btn-purple" href="tel:+15392377273">Call (539) 237-7273</a>
        <a class="btn btn-ghost" href="mailto:contact@noblefinancesolutions.com?subject=Financial%20Protection%20%26%20Retirement%20Review">Email Maunty</a>
        <a class="btn btn-ghost" href="https://s.blinq.me/A1pbR0qX7BKX" target="_blank" rel="noopener noreferrer">Save contact ↗</a>
      </div>
    </div>
  </div>
</dialog>





<!-- FAQ -->

<section class="section" id="faq">
  <div class="container faq-grid">
    <div class="reveal">
      <div class="eyebrow">FREQUENTLY ASKED QUESTIONS</div>
      <h2>Answers That Help You Move Forward.</h2>
      <p style="color:#68758b">
        Financial decisions can bring up important
        questions. Here are a few places to start.
      </p>
    </div>

    <div class="reveal">
      <details>
        <summary>What services does Noble Finance Solutions offer?</summary>
        <p>
          Life insurance, retirement income planning, long-term care,
          debt protection and final expense coverage.
        </p>
      </details>

      <details>
        <summary>Is the Financial Protection Health Check really free?</summary>
        <p>
          Yes. It's 10 quick questions, takes 2–3 minutes and comes with no obligation.
          You get a score and a snapshot of where your household is well protected
          and where there may be gaps.
        </p>
      </details>

      <details>
        <summary>What areas do you serve?</summary>
        <p>
          We serve families, retirees, and business owners in Tulsa County
          and surrounding areas.
        </p>
      </details>

      <details>
        <summary>Can I discuss my existing insurance coverage?</summary>
        <p>
          Yes. You can request a conversation about your
          current coverage and future protection needs.
        </p>
      </details>

      <details>
        <summary>When should I start retirement planning?</summary>
        <p>
          Planning can be useful at many stages of life.
          The right approach depends on your individual
          goals, resources and circumstances.
        </p>
      </details>

      <details>
        <summary>How can I get in touch?</summary>
        <p>
          Call <a href="tel:+15392377273" style="color:#1f5bb5;font-weight:700">(539) 237-7273</a>
          or email <a href="mailto:contact@noblefinancesolutions.com" style="color:#1f5bb5;font-weight:700">contact@noblefinancesolutions.com</a>
          to book your Financial Protection &amp; Retirement Review.
        </p>
      </details>
    </div>
  </div>
</section>

<!-- CONTACT -->

<section class="contact" id="contact">
  <div class="container">
    <div class="contact-panel reveal">
      <div class="eyebrow" style="color:#d8ad65">
        KNOW TODAY. PREPARE FOR TOMORROW.
      </div>

      <h2>Book Your Financial Protection &amp; Retirement Review.</h2>

      <p>
        A relaxed, no-pressure conversation about your family, your goals
        and the “what ifs” worth planning for.
      </p>

      <div class="contact-cards">
        <a href="tel:+15392377273"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></span>(539) 237-7273</a>
        <a href="mailto:contact@noblefinancesolutions.com"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/></svg></span>contact@noblefinancesolutions.com</a>
      </div>

      <a href="mailto:contact@noblefinancesolutions.com?subject=Financial%20Protection%20%26%20Retirement%20Review" class="btn btn-gold" id="bookBtn">
         Book My Review ↗
      </a>

      <div class="contact-tagline">
        <span>EDUCATION TODAY.</span><span>A STRONGER TOMORROW.</span>
      </div>
    </div>
  </div>
</section>

</main>

<!-- FOOTER -->

<footer>
  <div class="container">

    <div class="footer-grid">

      <div>
        <a href="#home" class="logo">
          <img class="brand-logo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/noble-logo-official-light.png" alt="Noble Finance Solutions" width="1207" height="559">
        </a>

        <p style="max-width:340px;margin-top:25px">
          Education-driven financial guidance for families,
          retirees, and business owners in Tulsa County
          and surrounding areas.
        </p>
        <a class="footer-bbb" href="https://www.bbb.org/us/ok/tulsa/profile/insurance-agency/noble-finance-solutions-1025-38111690/#sealclick" target="_blank" rel="noopener noreferrer" aria-label="BBB Accredited Business: view the BBB profile">
          <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/bbb-accredited-vertical.png" alt="BBB Accredited Business" width="175" height="260" loading="lazy">
        </a>
      </div>

      <div>
        <h4>Solutions</h4>
        <div class="footer-links">
          <a href="#risks" data-risk="0">Life Insurance</a>
          <a href="#risks" data-risk="1">Retirement Planning</a>
          <a href="#risks" data-risk="2">Long-Term Care</a>
          <a href="#risks" data-risk="3">Debt Protection</a>
          <a href="#risks" data-risk="4">Final Expense</a>
        </div>
      </div>

      <div>
        <h4>Get in Touch</h4>
        <div class="footer-links">
          <a href="tel:+15392377273">(539) 237-7273</a>
          <a href="mailto:contact@noblefinancesolutions.com">contact@noblefinancesolutions.com</a>
          <a href="#checkup">Free Health Check</a>
        </div>
      </div>
    </div>

    <div class="copyright">
      <p>© <span id="year"></span> Noble Finance Solutions. All rights reserved.</p>
    </div>

  </div>
</footer>

<script>
// Mobile navigation
const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

menuBtn.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuBtn.textContent = isOpen ? "✕" : "☰";
  menuBtn.setAttribute("aria-expanded", String(isOpen));
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuBtn.textContent = "☰";
    menuBtn.setAttribute("aria-expanded", "false");
  });
});

// Dynamic copyright year
document.getElementById("year").textContent =
  new Date().getFullYear();

// Scroll reveal animation
if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("active");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold:0.08 });

  document.querySelectorAll(".reveal").forEach(element => {
    observer.observe(element);
  });
} else {
  document.querySelectorAll(".reveal").forEach(element => {
    element.classList.add("active");
  });
}

// ================= 5 FINANCIAL RISKS EXPLORER =================
const RISKS = [
  {
    short: "Life Insurance",
    img: "<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-family-hd.jpg",
    stat: 40, prefix: "", suffix: "%", ring: 40,
    statLabel: "of U.S. adults say they need more life insurance",
    fact: "40% of U.S. adults say they need more life insurance.",
    text: "Life insurance provides financial security for your loved ones, helps cover daily living expenses, and keeps their future on track.",
    questions: ["Would your family be okay financially if something happened to you?", "Do you have enough coverage for your current needs?"]
  },
  {
    short: "Retirement Income",
    img: "<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-retirement-couple-hd.jpg",
    stat: 57, prefix: "", suffix: "%", ring: 57,
    statLabel: "of workers believe their savings will last throughout retirement",
    fact: "Only 57% of workers believe their savings will last throughout retirement.",
    text: "With longer life expectancies and market uncertainty, having a plan for retirement income is more important than ever.",
    questions: ["Will your retirement savings last as long as you do?", "Do you have a strategy to help protect your income from market downturns and inflation?"]
  },
  {
    short: "Long-Term Care",
    img: "<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-caregiver.jpg",
    stat: 70, prefix: "~", suffix: "%", ring: 70,
    statLabel: "chance someone turning 65 will need some form of long-term care",
    fact: "Someone turning 65 has nearly a 70% chance of needing some form of long-term care.",
    text: "The need for long-term care can happen to anyone and can be financially and emotionally challenging without a plan.",
    questions: ["Who would care for you, and who would pay for it?", "Do you want to protect your savings and give your family more options?"]
  },
  {
    short: "Debt Protection",
    img: "<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-home-keys.webp",
    stat: 18.8, prefix: "$", suffix: "T", ring: 100, decimals: 1,
    statLabel: "total U.S. household debt reached in 2026",
    fact: "U.S. household debt reached $18.8 trillion in 2026.",
    text: "Don't leave debt behind. A protection strategy can help keep debts, mortgage obligations, and other liabilities from becoming a family burden.",
    questions: ["What happens to the debt if your income disappears?", "Do you have a plan to help protect your home, assets, and loved ones?"]
  },
  {
    short: "Final Expense",
    img: "<?php echo esc_url( get_template_directory_uri() ); ?>/images/photo-sunrise-path.jpg",
    stat: 8000, prefix: "$", suffix: "+", ring: 100,
    statLabel: "median funeral costs can exceed this amount",
    fact: "Median funeral costs can exceed $8,000.",
    text: "Final expense planning can help provide funds for end-of-life costs and ease the burden on your loved ones during an already difficult time.",
    questions: ["Would money be immediately available for final expenses?", "Do you want to make the process easier for your family?"]
  }
];

const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const explorer = document.getElementById("riskExplorer");
const tabList = explorer.querySelector(".risk-tabs");
const panel = document.getElementById("riskPanel");
const RING_LEN = 263.9;
let currentRisk = 0;
let autoTimer = null;
let autoStopped = reduceMotion;

// Preload photos so tab switches are instant
RISKS.forEach(r => { const i = new Image(); i.src = r.img; });

RISKS.forEach((r, i) => {
  const b = document.createElement("button");
  b.className = "risk-tab";
  b.type = "button";
  b.setAttribute("role", "tab");
  b.id = "riskTab" + i;
  b.setAttribute("aria-controls", "riskPanel");
  b.innerHTML = `<span class="num">${i + 1}</span><span><strong>${r.short}</strong><small>${r.prefix}${formatNum(r.stat, r.decimals)}${r.suffix} · ${r.statLabel.split(" ").slice(0, 4).join(" ")}…</small></span><span class="timer"></span>`;
  b.addEventListener("click", () => { stopAuto(); showRisk(i); });
  tabList.appendChild(b);
});

tabList.addEventListener("keydown", e => {
  const keys = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 };
  if (!(e.key in keys)) return;
  e.preventDefault();
  stopAuto();
  const next = (currentRisk + keys[e.key] + RISKS.length) % RISKS.length;
  showRisk(next);
  document.getElementById("riskTab" + next).focus();
});

function formatNum(n, decimals = 0) {
  return n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

function countUp(el, r) {
  const write = v => el.textContent = r.prefix + formatNum(v, r.decimals) + r.suffix;
  if (reduceMotion) return write(r.stat);
  const start = performance.now(), dur = 1100;
  const step = t => {
    const p = Math.min((t - start) / dur, 1);
    write(r.stat * (1 - Math.pow(1 - p, 3)));
    if (p < 1 && el.dataset.run === String(r.stat)) requestAnimationFrame(step);
  };
  el.dataset.run = String(r.stat);
  requestAnimationFrame(step);
}

function showRisk(i) {
  currentRisk = i;
  const r = RISKS[i];
  tabList.querySelectorAll(".risk-tab").forEach((t, k) => {
    t.setAttribute("aria-selected", String(k === i));
    t.tabIndex = k === i ? 0 : -1;
  });
  panel.setAttribute("aria-labelledby", "riskTab" + i);
  document.getElementById("riskPhoto").style.backgroundImage = `url(${r.img})`;
  document.getElementById("riskNum").textContent = i + 1;
  document.getElementById("riskEyebrow").textContent = `RISK ${i + 1} OF 5`;
  document.getElementById("riskTitle").textContent = r.short;
  document.getElementById("riskFact").textContent = r.fact;
  document.getElementById("riskText").textContent = r.text;
  document.getElementById("statLabel").textContent = r.statLabel;
  document.getElementById("riskQuestions").innerHTML = r.questions.map(q => `<li>${q}</li>`).join("");
  document.getElementById("riskTalk").href =
    `mailto:contact@noblefinancesolutions.com?subject=${encodeURIComponent("Question about " + r.short)}`;

  const ring = document.getElementById("ringFg");
  ring.style.transition = "none";
  ring.style.strokeDashoffset = RING_LEN;
  ring.getBoundingClientRect();
  ring.style.transition = "";
  ring.style.strokeDashoffset = RING_LEN * (1 - r.ring / 100);
  countUp(document.getElementById("statValue"), r);

  panel.classList.remove("swap"); void panel.offsetWidth; panel.classList.add("swap");
  if (!autoStopped) scheduleAuto();
}

function scheduleAuto() {
  clearTimeout(autoTimer);
  explorer.classList.add("autoplay");
  autoTimer = setTimeout(() => showRisk((currentRisk + 1) % RISKS.length), 8000);
}
function stopAuto() {
  autoStopped = true;
  clearTimeout(autoTimer);
  explorer.classList.remove("autoplay");
}
explorer.addEventListener("pointerdown", stopAuto);

// Any link with data-risk (service cards, footer) opens that risk
document.querySelectorAll("[data-risk]").forEach(a =>
  a.addEventListener("click", () => { stopAuto(); showRisk(Number(a.dataset.risk)); })
);

// Start the explorer when it scrolls into view
let riskStarted = false;
const startRisks = () => { if (!riskStarted) { riskStarted = true; showRisk(currentRisk); } };
if ("IntersectionObserver" in window) {
  new IntersectionObserver((es, o) => {
    if (es[0].isIntersecting) { startRisks(); o.disconnect(); }
  }, { threshold: 0.3 }).observe(explorer);
} else startRisks();
// Fill content immediately (without animation) so it is never empty
(function prefill() {
  const was = autoStopped; autoStopped = true; showRisk(0); autoStopped = was; riskStarted = false;
})();

// ================= FINANCIAL PROTECTION HEALTH CHECK =================
const QUESTIONS = [
  { cat: 0, q: "If something happened to you, would your family be okay financially?" },
  { cat: 0, q: "Is your current life insurance coverage enough for your needs today?" },
  { cat: 1, q: "Are you confident your retirement savings will last as long as you do?" },
  { cat: 1, q: "Do you have a strategy to help protect your income from market downturns and inflation?" },
  { cat: 2, q: "If you needed long-term care, do you know who would provide it and how it would be paid for?" },
  { cat: 2, q: "Is your savings protected if you, or a spouse, needed extended care?" },
  { cat: 3, q: "If your income disappeared, is there a plan to cover your mortgage and other debts?" },
  { cat: 3, q: "Are your home and assets protected so debt wouldn't become a burden for your family?" },
  { cat: 4, q: "Would money be immediately available to cover final expenses?" },
  { cat: 4, q: "Have you made arrangements to make the process easier for your family?" }
];
const ANSWERS = [
  { label: "Yes, I'm confident", pts: 10 },
  { label: "Partly", pts: 5 },
  { label: "Not sure", pts: 2 },
  { label: "No", pts: 0 }
];
const TIERS = [
  { min: 80, name: "WELL PROTECTED", color: "#2f8a63", bg: "#e8f6ef",
    msg: "You've clearly put thought into protecting your household. A periodic review helps make sure your plan keeps up as life changes." },
  { min: 60, name: "SOLID FOUNDATION", color: "#1f5bb5", bg: "#eaf1fb",
    msg: "You have good pieces in place, with a few gaps worth a closer look. Small adjustments now can make a big difference later." },
  { min: 40, name: "ROOM TO STRENGTHEN", color: "#a87a2f", bg: "#fbf2e2",
    msg: "Some important areas are uncovered or uncertain. The good news: these are very solvable with the right plan." },
  { min: 0, name: "LET'S TALK SOON", color: "#b4537b", bg: "#fbeef3",
    msg: "Several of life's “what ifs” could leave your family exposed today. A short, no-pressure review is a great first step." }
];

const quiz = document.getElementById("quiz");
let answers = [];
let lead = { name: "", email: "", phone: "", consent: false };
let qIndex = 0;

function quizStart() {
  answers = []; qIndex = 0;
  quiz.innerHTML = `
    <div class="quiz-start">
      <div class="eyebrow">YOUR FINANCIAL PROTECTION SCORE</div>
      <h3>10 questions. 2–3 minutes.<br>One clear snapshot.</h3>
      <p>See where your household is well protected, and where a little planning could go a long way.</p>
      <div class="cover-list">
        ${RISKS.map((r, i) => `<div><b>${i + 1}</b>${r.short}</div>`).join("")}
      </div>
      <div class="chips"><span>✓ Free</span><span>✓ No obligation</span><span>✓ PDF results by email</span></div>
      <form class="lead-form" id="leadForm" novalidate>
        <p class="lead-title">Where should we send your results?</p>
        <div class="lead-grid">
          <label>Full name<input type="text" name="name" autocomplete="name" required value="${esc(lead.name)}"></label>
          <label>Email<input type="email" name="email" autocomplete="email" required value="${esc(lead.email)}"></label>
          <label>Phone<input placeholder="Optional" type="tel" name="phone" autocomplete="tel" value="${esc(lead.phone)}"></label>
        </div>
        <label class="hp" aria-hidden="true">Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
        <label class="consent"><input type="checkbox" name="consent" ${lead.consent ? "checked" : ""} required>
          <span>Email me a PDF of my results, and I&rsquo;d like Noble Finance Solutions to contact me about them. I understand this is an educational follow-up, not an insurance application, and no purchase is required.</span></label>
        <p class="lead-error" id="leadError" role="alert"></p>
        <button class="btn btn-purple" id="quizGo" type="submit">Start My Health Check ↗</button>
      </form>
    </div>`;
  document.getElementById("leadForm").addEventListener("submit", e => {
    e.preventDefault();
    const f = e.target, err = document.getElementById("leadError");
    const name = f.name.value.trim(), email = f.email.value.trim(), phone = f.phone.value.trim();
    let msg = "";
    if (name.length < 2) msg = "Please enter your full name.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) msg = "Please enter a valid email address.";
    else if (phone && phone.replace(/\D/g, "").length < 7) msg = "Please check your phone number, or leave it blank.";
    else if (!f.consent.checked) msg = "Please tick the box so we can send your results.";
    err.textContent = msg;
    if (msg) return;
    lead = { name, email, phone, consent: true, website: f.website.value, started: Date.now() };
    renderQuestion(true);
  });
}

function esc(v) { return String(v || "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

function renderQuestion(focus) {
  const item = QUESTIONS[qIndex];
  const pct = (qIndex / QUESTIONS.length) * 100;
  quiz.innerHTML = `
    <div class="quiz-meta">
      <span class="cat">${item.cat + 1} · ${RISKS[item.cat].short}</span>
      <span>Question ${qIndex + 1} of ${QUESTIONS.length}</span>
    </div>
    <div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(pct)}"><span style="width:${pct}%"></span></div>
    <p class="quiz-q" id="qText">${item.q}</p>
    <div class="answers" role="group" aria-labelledby="qText">
      ${ANSWERS.map((a, i) => `<button type="button" class="answer${answers[qIndex] === i ? " chosen" : ""}" data-i="${i}"><i>${"ABCD"[i]}</i>${a.label}</button>`).join("")}
    </div>
    <div class="quiz-nav">
      <button type="button" class="link-btn" id="qBack" ${qIndex === 0 ? "disabled" : ""}>← Back</button>
      <span>Tip: press A–D</span>
    </div>`;
  quiz.querySelectorAll(".answer").forEach(b => b.addEventListener("click", () => choose(Number(b.dataset.i))));
  document.getElementById("qBack").addEventListener("click", () => { if (qIndex > 0) { qIndex--; renderQuestion(true); } });
  if (focus) quiz.querySelector(".answer").focus({ preventScroll: true });
}

function choose(i) {
  answers[qIndex] = i;
  quiz.querySelectorAll(".answer").forEach(b => b.classList.toggle("chosen", Number(b.dataset.i) === i));
  setTimeout(() => {
    if (qIndex < QUESTIONS.length - 1) { qIndex++; renderQuestion(true); }
    else renderResult();
  }, reduceMotion ? 0 : 260);
}

document.addEventListener("keydown", e => {
  if (!quiz.querySelector(".answer") || e.ctrlKey || e.metaKey || e.altKey) return;
  const k = "abcd".indexOf(e.key.toLowerCase());
  const rect = quiz.getBoundingClientRect();
  const visible = rect.top < innerHeight && rect.bottom > 0;
  if (k >= 0 && visible) choose(k);
});

function renderResult() {
  const cats = RISKS.map(() => 0);
  answers.forEach((a, i) => cats[QUESTIONS[i].cat] += ANSWERS[a].pts);
  const score = cats.reduce((x, y) => x + y, 0);
  const tier = TIERS.find(t => score >= t.min);
  const low = Math.min(...cats);
  const priority = cats.indexOf(low);
  const barColor = v => v >= 16 ? "#2f8a63" : v >= 10 ? "#1f5bb5" : v >= 6 ? "#d8ad65" : "#b4537b";

  quiz.innerHTML = `
    <svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
      <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1f5bb5"/><stop offset="1" stop-color="#d8ad65"/></linearGradient>
    </defs></svg>
    <div class="result-top">
      <div class="gauge">
        <svg viewBox="0 0 120 120" aria-hidden="true">
          <circle class="g-bg" cx="60" cy="60" r="52" fill="none" stroke-width="12"/>
          <circle class="g-fg" id="gFg" cx="60" cy="60" r="52" fill="none" stroke-width="12" stroke-dasharray="326.7" stroke-dashoffset="326.7"/>
        </svg>
        <div class="gauge-label"><div><strong id="gNum">0</strong><small>OUT OF 100</small></div></div>
      </div>
      <div>
        <span class="tier" style="color:${tier.color};background:${tier.bg}">${tier.name}</span>
        <h3>Your Financial Protection Score is ${score}.</h3>
        <p>${tier.msg}</p>
      </div>
    </div>
    <div class="cat-bars">
      ${cats.map((v, i) => `
        <div class="cat-bar${i === priority && low < 20 ? " priority" : ""}">
          <span>${RISKS[i].short}</span>
          <div class="track"><div class="fill" data-w="${v * 5}" style="background:${barColor(v)}"></div></div>
          <em>${v}/20</em>
        </div>`).join("")}
    </div>
    <div class="result-actions">
      <a class="btn btn-purple" id="resBook">Book My Review ↗</a>
      ${low < 20 ? `<a class="btn btn-ghost" href="#risks" id="resRisk">Explore ${RISKS[priority].short}</a>` : ""}
      <button type="button" class="link-btn" id="resRetake">↺ Retake</button>
    </div>
    <div class="deliver" id="deliver" role="status" aria-live="polite"><span class="spin"></span> Preparing your PDF report&hellip;</div>`;

  const body = [
    `Hi Maunty,`, ``,
    `I just took the Financial Protection Health Check on your website and scored ${score}/100 (${tier.name.toLowerCase()}).`, ``,
    ...cats.map((v, i) => `- ${RISKS[i].short}: ${v}/20`), ``,
    `I'd like to book a Financial Protection & Retirement Review.`, ``,
    `Name:`, `Best phone:`, `Best time to reach me:`
  ].join("\n");
  const mail = `mailto:contact@noblefinancesolutions.com?subject=${encodeURIComponent(`Health Check score ${score}: booking a review`)}&body=${encodeURIComponent(body)}`;
  document.getElementById("resBook").href = mail;
  document.getElementById("bookBtn").href = mail;

  document.getElementById("resRetake").addEventListener("click", () => { quizStart(); quiz.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "center" }); });
  const rr = document.getElementById("resRisk");
  if (rr) rr.addEventListener("click", () => { stopAuto(); showRisk(priority); });

  deliverResults({ score, tier, cats, priority, low });

  requestAnimationFrame(() => requestAnimationFrame(() => {
    document.getElementById("gFg").style.strokeDashoffset = 326.7 * (1 - score / 100);
    quiz.querySelectorAll(".fill").forEach(f => f.style.width = f.dataset.w + "%");
    const n = document.getElementById("gNum");
    if (reduceMotion) { n.textContent = score; return; }
    const t0 = performance.now();
    const tick = t => { const p = Math.min((t - t0) / 1500, 1); n.textContent = Math.round(score * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  }));
}

// ================= HEALTH CHECK: PDF REPORT + EMAIL DELIVERY =================
const NFS_LOGO = "<?php echo esc_url( get_template_directory_uri() ); ?>/images/noble-logo-official.png";
let lastReport = null;

function loadImageData(src, width = 520) {
  // Draw the logo onto a small white canvas so the PDF stays light (~100 KB).
  return new Promise(res => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = width; c.height = Math.round(img.height * width / img.width);
      const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height);
      x.drawImage(img, 0, 0, c.width, c.height);
      res(c.toDataURL("image/jpeg", 0.9));
    };
    img.onerror = () => res(null);
    img.src = src;
  });
}

async function buildReportPdf(r) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: "pt", format: "letter", compress: true });
  const W = 612, M = 54, navy = [11, 45, 99], gold = [201, 161, 90], ink = [29, 36, 51], muted = [91, 100, 114];
  const date = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  const logo = await loadImageData(NFS_LOGO);

  // header
  if (logo) doc.addImage(logo, "JPEG", M, 40, 132, 61);
  doc.setFont("helvetica", "bold"); doc.setFontSize(9); doc.setTextColor(...navy);
  doc.text("Maunty Wright", W - M, 56, { align: "right" });
  doc.setFont("helvetica", "normal"); doc.setTextColor(...muted);
  doc.text(["Life Insurance Broker & Finance Professional", "Tulsa, Oklahoma · NPN #22312170", "(539) 237-7273 · contact@noblefinancesolutions.com"], W - M, 69, { align: "right" });
  doc.setDrawColor(...navy); doc.setLineWidth(1.5); doc.line(M, 112, W - M, 112);
  doc.setDrawColor(...gold); doc.setLineWidth(2); doc.line(M, 116, M + 80, 116);

  // title
  let y = 150;
  doc.setTextColor(...gold); doc.setFont("helvetica", "bold"); doc.setFontSize(9);
  doc.text("FINANCIAL PROTECTION HEALTH CHECK", M, y);
  doc.setTextColor(...ink); doc.setFontSize(22);
  doc.text(`Results for ${r.name}`, M, y + 26);
  doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(...muted);
  doc.text(date, M, y + 44);

  // score block
  y = 220;
  doc.setFillColor(243, 245, 248); doc.roundedRect(M, y, W - 2 * M, 112, 10, 10, "F");
  doc.setFillColor(...navy); doc.circle(M + 62, y + 56, 40, "F");
  doc.setTextColor(255, 255, 255); doc.setFont("helvetica", "bold"); doc.setFontSize(28);
  doc.text(String(r.score), M + 62, y + 62, { align: "center" });
  doc.setFontSize(7); doc.text("OUT OF 100", M + 62, y + 76, { align: "center" });
  doc.setTextColor(...navy); doc.setFontSize(10); doc.text(r.tier.name, M + 122, y + 34);
  doc.setTextColor(...ink); doc.setFontSize(15); doc.text(`Your Financial Protection Score is ${r.score}.`, M + 122, y + 54);
  doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(...muted);
  doc.text(doc.splitTextToSize(r.tier.msg.replace(/[“”]/g, '"'), W - 2 * M - 140), M + 122, y + 72);

  // category bars
  y = 362;
  doc.setTextColor(...ink); doc.setFont("helvetica", "bold"); doc.setFontSize(12);
  doc.text("Your score by area", M, y);
  y += 20;
  r.cats.forEach((v, i) => {
    const pr = i === r.priority && r.low < 20;
    doc.setFont("helvetica", pr ? "bold" : "normal"); doc.setFontSize(10);
    doc.setTextColor(...(pr ? [180, 83, 123] : ink));
    doc.text(RISKS[i].short + (pr ? "  (priority)" : ""), M, y + 9);
    doc.setFillColor(238, 240, 245); doc.roundedRect(M + 170, y, 260, 10, 5, 5, "F");
    const col = v >= 16 ? [47, 138, 99] : v >= 10 ? [31, 91, 181] : v >= 6 ? [216, 173, 101] : [180, 83, 123];
    if (v > 0) { doc.setFillColor(...col); doc.roundedRect(M + 170, y, Math.max(10, 260 * v / 20), 10, 5, 5, "F"); }
    doc.setTextColor(...muted); doc.setFont("helvetica", "normal");
    doc.text(`${v}/20`, W - M, y + 9, { align: "right" });
    y += 24;
  });

  // areas worth a closer look
  y += 10;
  const focus = r.cats.map((v, i) => ({ v, i })).filter(o => o.v < 16).sort((a, b) => a.v - b.v).slice(0, 2);
  if (focus.length) {
    doc.setTextColor(...ink); doc.setFont("helvetica", "bold"); doc.setFontSize(12);
    doc.text("Areas worth a closer look", M, y); y += 18;
    focus.forEach(o => {
      const k = RISKS[o.i];
      doc.setFont("helvetica", "bold"); doc.setFontSize(10.5); doc.setTextColor(...navy);
      doc.text(k.short, M, y); y += 14;
      doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(...muted);
      const lines = doc.splitTextToSize(`${k.fact} ${k.questions.map(q => "• " + q).join("  ")}`, W - 2 * M);
      doc.text(lines, M, y); y += lines.length * 12 + 10;
    });
  }

  // next steps
  y = Math.max(y + 4, 628);
  doc.setFillColor(...navy); doc.roundedRect(M, y, W - 2 * M, 74, 10, 10, "F");
  doc.setTextColor(255, 255, 255); doc.setFont("helvetica", "bold"); doc.setFontSize(12);
  doc.text("Next step: a free Financial Protection & Retirement Review", M + 18, y + 26);
  doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(214, 222, 238);
  doc.text("Call (539) 237-7273 or email contact@noblefinancesolutions.com. No pressure, no obligation.", M + 18, y + 46);
  doc.text("noblefinancesolutions.com", M + 18, y + 61);

  // disclaimer
  doc.setFontSize(7.5); doc.setTextColor(138, 147, 163);
  doc.text(doc.splitTextToSize("This checkup is for educational purposes and provides a general snapshot based on your responses. It is not a comprehensive financial, insurance, investment, tax, or legal analysis.", W - 2 * M), M, 742);
  return doc;
}

async function deliverResults(res) {
  const box = document.getElementById("deliver");
  const data = { ...res, name: lead.name, email: lead.email, phone: lead.phone };
  const fileName = `Noble-Health-Check-${(lead.name || "Results").replace(/[^A-Za-z0-9]+/g, "-")}.pdf`;
  let doc;
  try {
    for (let i = 0; i < 50 && !window.jspdf; i++) await new Promise(r => setTimeout(r, 100));
    doc = await buildReportPdf(data);
  } catch (e) {
    box.innerHTML = "We couldn&rsquo;t create your PDF just now, but your results are shown above. Use <b>Book My Review</b> to reach Maunty.";
    return;
  }
  lastReport = { doc, fileName };
  const dl = `<button type="button" class="link-btn" id="dlPdf">Download PDF</button>`;
  const bindDl = () => document.getElementById("dlPdf").addEventListener("click", () => lastReport.doc.save(lastReport.fileName));

  if (!window.NFS_API) {               // preview hosting without the email service
    box.innerHTML = `Your PDF report is ready. ${dl}`; bindDl(); return;
  }
  box.innerHTML = `<span class="spin"></span> Emailing your PDF to <b>${esc(lead.email)}</b>&hellip;`;
  const fd = new FormData();
  fd.append("action", "nfs_checkup");
  fd.append("name", lead.name); fd.append("email", lead.email); fd.append("phone", lead.phone);
  fd.append("consent", "1"); fd.append("website", lead.website || "");
  fd.append("elapsed", String(Math.round((Date.now() - (lead.started || Date.now())) / 1000)));
  fd.append("score", String(res.score)); fd.append("tier", res.tier.name);
  fd.append("cats", JSON.stringify(res.cats));
  fd.append("answers", JSON.stringify(answers));
  fd.append("pdf", doc.output("datauristring"));
  try {
    const r = await fetch(window.NFS_API.url, { method: "POST", body: fd, credentials: "same-origin" });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.success) throw new Error((j.data && j.data.msg) || "send failed");
    box.classList.add("ok");
    box.innerHTML = `✓ Your PDF report is on its way to <b>${esc(lead.email)}</b>. Check your spam folder if you don&rsquo;t see it in a few minutes. ${dl}`;
  } catch (e) {
    box.classList.add("warn");
    box.innerHTML = `We couldn&rsquo;t email your report right now${e.message && e.message !== "send failed" ? ` (${esc(e.message)})` : ""}. You can download it here: ${dl}`;
  }
  bindDl();
}

quizStart();

// Header shadow on scroll
const hdr = document.querySelector("header");
addEventListener("scroll", () => hdr.classList.toggle("scrolled", scrollY > 10), { passive: true });

// Advisor full-bio dialog
const bioDialog = document.getElementById("bioDialog");
let bioOpener = null;
document.querySelectorAll("[data-open-bio]").forEach(b => b.addEventListener("click", () => {
  bioOpener = b;
  if (bioDialog.showModal) bioDialog.showModal(); else bioDialog.setAttribute("open", "");
  bioDialog.querySelector(".bio-main").scrollTop = 0;
}));
bioDialog.querySelector("[data-close-bio]").addEventListener("click", () => bioDialog.close());
bioDialog.addEventListener("click", e => { if (e.target === bioDialog) bioDialog.close(); });
bioDialog.addEventListener("close", () => bioOpener && bioOpener.focus());
</script>

</body>
</html>
